void nw_traco()
{ 
    int c1,c3,c4,c5,c7,c9,c11,c10;
for( c1 = 0; c1 <= floord(N - 1, 8); c1 += 1)
  #pragma omp parallel for schedule(dynamic, 1) shared(c1) private(c3,c4,c7,c9,c10,c5,c11)
  for( c3 = max(0, c1 - (N + 15) / 16 + 1); c3 <= min(c1, (N - 1) / 16); c3 += 1)
    for( c4 = 0; c4 <= 4; c4 += 1) {
      if (c4 == 4) {
        for( c7 = 16 * c1 - 16 * c3 + 1; c7 <= min(N, 16 * c1 - 16 * c3 + 16); c7 += 1)
          for( c9 = 16 * c3 + 1; c9 <= min(N, 16 * c3 + 16); c9 += 1) {
            if (16 * c3 + c7 >= 16 * c1 + 2)
              for( c11 = 1; c11 <= c7; c11 += 1)
                m1[c7][c9] = MAX(m1[c7][c9] ,F[c7-c11][c9] - W[c11]);
            for( c10 = max(3, 16 * c3 - c9 + 5); c10 <= 4; c10 += 1) {
              if (c10 == 4) {
                F[c7][c9] = MAX(0, MAX( F[c7-1][c9-1] + s(a[c7], b[c7]), MAX(m1[c7][c9], m2[c7][c9])));
              } else {
                for( c11 = 1; c11 <= c9; c11 += 1)
                  m2[c7][c9] = MAX(m2[c7][c9] ,F[c7][c9-c11] - W[c11]);
              }
            }
          }
      } else if (c4 == 3) {
        for( c5 = 0; c5 <= c3; c5 += 1)
          for( c7 = 16 * c1 - 16 * c3 + 1; c7 <= min(N, 16 * c1 - 16 * c3 + 16); c7 += 1)
            for( c11 = 16 * c5 + 1; c11 <= min(16 * c3 + 1, 16 * c5 + 16); c11 += 1)
              m2[c7][(16*c3+1)] = MAX(m2[c7][(16*c3+1)] ,F[c7][(16*c3+1)-c11] - W[c11]);
      } else if (c4 == 2) {
        for( c7 = 16 * c1 - 16 * c3 + 1; c7 <= min(N, 16 * c1 - 16 * c3 + 16); c7 += 1)
          for( c9 = 16 * c3 + 1; c9 <= min(N, 16 * c3 + 16); c9 += 1)
            m2[c7][c9] = INT_MIN;
      } else if (c4 == 1) {
        for( c5 = 0; c5 <= c1 - c3; c5 += 1)
          for( c9 = 16 * c3 + 1; c9 <= min(N, 16 * c3 + 16); c9 += 1)
            for( c11 = 16 * c5 + 1; c11 <= min(16 * c1 - 16 * c3 + 1, 16 * c5 + 16); c11 += 1)
              m1[(16*c1-16*c3+1)][c9] = MAX(m1[(16*c1-16*c3+1)][c9] ,F[(16*c1-16*c3+1)-c11][c9] - W[c11]);
      } else {
        for( c7 = 16 * c1 - 16 * c3 + 1; c7 <= min(N, 16 * c1 - 16 * c3 + 16); c7 += 1)
          for( c9 = 16 * c3 + 1; c9 <= min(N, 16 * c3 + 16); c9 += 1)
            m1[c7][c9] = INT_MIN;
      }
    }




}