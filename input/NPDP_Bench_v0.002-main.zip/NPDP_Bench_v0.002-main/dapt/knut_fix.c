int MIN(int, int);

void foo2(int n, int  **ck, int **w){
#pragma scop
	for(int i=n-1; i>=1; i--)
		for(int j=i+1; j<=n; j++)
			for(int k=i+1; k<j; k++)
				ck[i][j] = MIN(ck[i][j], w[i][j]+ck[i][k]+ck[k][j]);
#pragma endscop
}



//Tiles 2D 16x16:
/*
//dapt filename=./work_test.c size=16 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = -1; w0 < floord(n, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(w0 - (n + 16) / 16 + 1, -((n + 13) / 16)); h0 < 0; h0 += 1) {
    for (int i0 = max(max(-n + 2, -16 * w0 + 16 * h0 - 13), 16 * h0); i0 <= 16 * h0 + 15; i0 += 1) {
      for (int i1 = max(16 * w0 - 16 * h0, -i0 + 2); i1 <= min(n, 16 * w0 - 16 * h0 + 15); i1 += 1) {
        for (int i2 = -i0 + 1; i2 < i1; i2 += 1) {
          ck[-i0][i1] = MIN(ck[-i0][i1], (w[-i0][i1] + ck[-i0][i2]) + ck[i2][i1]);
        }
      }
    }
  }
}
*/

//Tiles 2D 16x16 with timeline=2:
/*
//dapt filename=./work_test.c size=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 sizetime1=1 sizetime2=1 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = -1; w0 < floord(n, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(w0 - (n + 16) / 16 + 1, -((n + 13) / 16)); h0 < 0; h0 += 1) {
    for (int t0 = max(1, 8 * w0); t0 <= min(8 * w0 + 15, 8 * h0 + (n + 1) / 2 + 7); t0 += 1) {
      for (int i0 = max(max(16 * h0, -16 * w0 + 16 * h0 + 2 * t0 - 15), -n + 2 * t0); i0 <= min(16 * h0 + 15, -16 * w0 + 16 * h0 + 2 * t0 + 1); i0 += 1) {
        for (int i1 = max(16 * w0 - 16 * h0, 2 * t0 - i0); i1 <= min(min(n, 16 * w0 - 16 * h0 + 15), 2 * t0 - i0 + 1); i1 += 1) {
          for (int i2 = -i0 + 1; i2 < i1; i2 += 1) {
            ck[-i0][i1] = MIN(ck[-i0][i1], (w[-i0][i1] + ck[-i0][i2]) + ck[i2][i1]);
          }
        }
      }
    }
  }
}
 */

//Tiles 2D 16x16 with sequential tiles 4x4:
 /*
//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = -1; w0 < floord(n, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(w0 - (n + 16) / 16 + 1, -((n + 13) / 16)); h0 < 0; h0 += 1) {
    for (int t0 = max(-1, 4 * w0); t0 <= min(4 * w0 + 6, 4 * h0 + n / 4 + 3); t0 += 1) {
      for (int i0 = max(max(max(max(-n + 2, 16 * h0), -16 * w0 + 16 * h0 + 4 * t0 - 12), 16 * h0 - 4 * t0 - 1), -n + 4 * t0); i0 <= min(16 * h0 + 15, -16 * w0 + 16 * h0 + 4 * t0 + 3); i0 += 1) {
        for (int i1 = max(-i0 + 2, -((-i0 + 3) % 4) + 4 * t0 - i0 + 3); i1 <= min(n, -((-i0 + 3) % 4) + 4 * t0 - i0 + 6); i1 += 1) {
          for (int i2 = -i0 + 1; i2 < i1; i2 += 1) {
            ck[-i0][i1] = MIN(ck[-i0][i1], (w[-i0][i1] + ck[-i0][i2]) + ck[i2][i1]);
          }
        }
      }
    }
  }
}

*/

