int MIN(int, int);

void foo2(int N, int **V, int **W, int **EFL, int **EHF){
#pragma scop
	for (int i = N-1; i >= 0; i--){
		for (int j = i+1; j < N; j++) {
			for (int k = i+1; k < j; k++){
				for(int m=k+1; m <j; m++){
					if(k-i + j - m > 2 && k-i + j - m < 30)
						V[i][j] = MIN(V[k][m] + EFL[i][j], V[i][j]);
				}
				W[i][j] += MIN ( MIN(W[i][k], W[k+1][j]), W[i][j]);
				if(k < j-1)
					V[i][j] = MIN(W[i+1][k] + W[k+1][j-1], V[i][j]);
			}
			V[i][j] = MIN( MIN (V[i+1][j-1], EHF[i][j]), V[i][j]);
			W[i][j] = MIN( MIN ( MIN ( W[i+1][j], W[i][j-1]), V[i][j]), W[i][j]);
		}
	}
#pragma endscop
}

//Tiles 2D 16x16:
/*
//dapt filename=./work_test.c size=16 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))

if (N >= 2) {
  for (int w0 = max(-1, -((N + 13) / 16)); w0 <= (N - 1) / 16; w0 += 1) {
    #pragma omp parallel for
    for (int h0 = max(w0 - (N + 15) / 16 + 1, -((N + 13) / 16)); h0 <= min(0, w0); h0 += 1) {
      {
        if (N + 16 * h0 <= 2 && 16 * w0 + 15 >= N + 16 * h0) {
          V[N - 2][N - 1] = MIN(MIN(V[N - 1][N - 2], EHF[N - 2][N - 1]), V[N - 2][N - 1]);
          W[N - 2][N - 1] = MIN(MIN(MIN(W[N - 1][N - 1], W[N - 2][N - 2]), V[N - 2][N - 1]), W[N - 2][N - 1]);
        } else if (w0 == -1) {
          V[-16 * h0 - 2][-16 * h0 - 1] = MIN(MIN(V[-16 * h0 - 1][-16 * h0 - 2], EHF[-16 * h0 - 2][-16 * h0 - 1]), V[-16 * h0 - 2][-16 * h0 - 1]);
          W[-16 * h0 - 2][-16 * h0 - 1] = MIN(MIN(MIN(W[-16 * h0 - 1][-16 * h0 - 1], W[-16 * h0 - 2][-16 * h0 - 2]), V[-16 * h0 - 2][-16 * h0 - 1]), W[-16 * h0 - 2][-16 * h0 - 1]);
        }
        for (int i0 = max(max(-N + 3, -16 * w0 + 16 * h0 - 13), 16 * h0); i0 <= min(0, 16 * h0 + 15); i0 += 1) {
          for (int i1 = max(16 * w0 - 16 * h0, -i0 + 1); i1 <= min(N - 1, 16 * w0 - 16 * h0 + 15); i1 += 1) {
            {
              for (int i3 = -i0 + 1; i3 < i1; i3 += 1) {
                {
                  for (int i5 = max(i0 + i1 + i3 - 29, i3 + 1); i5 < min(i1, i0 + i1 + i3 - 2); i5 += 1) {
                    V[-i0][i1] = MIN(V[i3][i5] + EFL[-i0][i1], V[-i0][i1]);
                  }
                  if (i0 + i3 >= 3) {
                    W[-i0][i1] += MIN(MIN(W[-i0][i3], W[i3 + 1][i1]), W[-i0][i1]);
                  } else {
                    W[-i0][i1] += MIN(MIN(W[-i0][i3], W[i3 + 1][i1]), W[-i0][i1]);
                  }
                  if (i1 >= i3 + 2) {
                    if (i0 + i3 >= 3) {
                      V[-i0][i1] = MIN(W[-i0 + 1][i3] + W[i3 + 1][i1 - 1], V[-i0][i1]);
                    } else {
                      V[-i0][i1] = MIN(W[-i0 + 1][i3] + W[i3 + 1][i1 - 1], V[-i0][i1]);
                    }
                  }
                }
              }
              if (i0 + i1 >= 30) {
                V[-i0][i1] = MIN(MIN(V[-i0 + 1][i1 - 1], EHF[-i0][i1]), V[-i0][i1]);
              } else {
                V[-i0][i1] = MIN(MIN(V[-i0 + 1][i1 - 1], EHF[-i0][i1]), V[-i0][i1]);
              }
              if (i0 + i1 >= 30) {
                W[-i0][i1] = MIN(MIN(MIN(W[-i0 + 1][i1], W[-i0][i1 - 1]), V[-i0][i1]), W[-i0][i1]);
              } else {
                W[-i0][i1] = MIN(MIN(MIN(W[-i0 + 1][i1], W[-i0][i1 - 1]), V[-i0][i1]), W[-i0][i1]);
              }
            }
          }
        }
      }
    }
  }
}
*/

//Tiles 2D 16x16 with timeline=2:
/*
//dapt filename=./work_test.c size=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 method=2 --debug-print-on
 //or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 sizetime1=1 sizetime2=1 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = max(-1, floord(-N + 2, 16)); w0 <= floord(N - 1, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(w0 - (N + 15) / 16 + 1, -((N + 13) / 16)); h0 <= min(0, w0); h0 += 1) {
    for (int t0 = max(0, 8 * w0); t0 <= min(min(min(8 * w0 + 15, 8 * w0 - 8 * h0 + 7), 8 * h0 + N / 2 + 7), (N + 1) / 2 - 1); t0 += 1) {
      for (int i0 = max(max(max(max(-N + 2, -16 * w0 + 16 * h0 - 14), 16 * h0), -16 * w0 + 16 * h0 + 2 * t0 - 15), -N + 2 * t0 + 1); i0 <= min(min(0, 16 * h0 + 15), -16 * w0 + 16 * h0 + 2 * t0 + 1); i0 += 1) {
        for (int i1 = max(max(16 * w0 - 16 * h0, 2 * t0 - i0), -i0 + 1); i1 <= min(min(N - 1, 16 * w0 - 16 * h0 + 15), 2 * t0 - i0 + 1); i1 += 1) {
          {
            for (int i3 = -i0 + 1; i3 < i1; i3 += 1) {
              {
                for (int i5 = max(i0 + i1 + i3 - 29, i3 + 1); i5 < min(i1, i0 + i1 + i3 - 2); i5 += 1) {
                  V[-i0][i1] = MIN(V[i3][i5] + EFL[-i0][i1], V[-i0][i1]);
                }
                if (i0 + i3 >= 3) {
                  W[-i0][i1] += MIN(MIN(W[-i0][i3], W[i3 + 1][i1]), W[-i0][i1]);
                } else {
                  W[-i0][i1] += MIN(MIN(W[-i0][i3], W[i3 + 1][i1]), W[-i0][i1]);
                }
                if (i1 >= i3 + 2) {
                  if (i0 + i3 >= 3) {
                    V[-i0][i1] = MIN(W[-i0 + 1][i3] + W[i3 + 1][i1 - 1], V[-i0][i1]);
                  } else {
                    V[-i0][i1] = MIN(W[-i0 + 1][i3] + W[i3 + 1][i1 - 1], V[-i0][i1]);
                  }
                }
              }
            }
            if (i0 + i1 >= 30) {
              V[-i0][i1] = MIN(MIN(V[-i0 + 1][i1 - 1], EHF[-i0][i1]), V[-i0][i1]);
            } else {
              V[-i0][i1] = MIN(MIN(V[-i0 + 1][i1 - 1], EHF[-i0][i1]), V[-i0][i1]);
            }
            if (i0 + i1 >= 30) {
              W[-i0][i1] = MIN(MIN(MIN(W[-i0 + 1][i1], W[-i0][i1 - 1]), V[-i0][i1]), W[-i0][i1]);
            } else {
              W[-i0][i1] = MIN(MIN(MIN(W[-i0 + 1][i1], W[-i0][i1 - 1]), V[-i0][i1]), W[-i0][i1]);
            }
          }
        }
      }
    }
  }
}
 */

//Tiles 2D 16x16 with sequential tiles 4x4:
 /*
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=1 sizetime1=4 sizetime2=4 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = max(-1, floord(-N + 2, 16)); w0 <= floord(N - 1, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(w0 - (N + 15) / 16 + 1, -((N + 13) / 16)); h0 <= min(0, w0); h0 += 1) {
    for (int t0 = max(-1, 4 * w0); t0 <= min(min(min(4 * w0 + 6, 4 * w0 - 4 * h0 + 3), (N - 1) / 4), 4 * h0 + (N - 1) / 4 + 3); t0 += 1) {
      for (int i0 = max(max(max(max(-N + 2, 16 * h0), -16 * w0 + 16 * h0 + 4 * t0 - 12), 16 * h0 - 4 * t0 - 2), -N + 4 * t0 + 1); i0 <= min(min(0, 16 * h0 + 15), -16 * w0 + 16 * h0 + 4 * t0 + 3); i0 += 1) {
        for (int i1 = max(-i0 + 1, -((-i0 + 3) % 4) + 4 * t0 - i0 + 3); i1 <= min(N - 1, -((-i0 + 3) % 4) + 4 * t0 - i0 + 6); i1 += 1) {
          {
            for (int i3 = -i0 + 1; i3 < i1; i3 += 1) {
              {
                for (int i5 = max(i0 + i1 + i3 - 29, i3 + 1); i5 < min(i1, i0 + i1 + i3 - 2); i5 += 1) {
                  V[-i0][i1] = MIN(V[i3][i5] + EFL[-i0][i1], V[-i0][i1]);
                }
                if (i0 + i3 >= 3) {
                  W[-i0][i1] += MIN(MIN(W[-i0][i3], W[i3 + 1][i1]), W[-i0][i1]);
                } else {
                  W[-i0][i1] += MIN(MIN(W[-i0][i3], W[i3 + 1][i1]), W[-i0][i1]);
                }
                if (i1 >= i3 + 2) {
                  if (i0 + i3 >= 3) {
                    V[-i0][i1] = MIN(W[-i0 + 1][i3] + W[i3 + 1][i1 - 1], V[-i0][i1]);
                  } else {
                    V[-i0][i1] = MIN(W[-i0 + 1][i3] + W[i3 + 1][i1 - 1], V[-i0][i1]);
                  }
                }
              }
            }
            if (i0 + i1 >= 30) {
              V[-i0][i1] = MIN(MIN(V[-i0 + 1][i1 - 1], EHF[-i0][i1]), V[-i0][i1]);
            } else {
              V[-i0][i1] = MIN(MIN(V[-i0 + 1][i1 - 1], EHF[-i0][i1]), V[-i0][i1]);
            }
            if (i0 + i1 >= 30) {
              W[-i0][i1] = MIN(MIN(MIN(W[-i0 + 1][i1], W[-i0][i1 - 1]), V[-i0][i1]), W[-i0][i1]);
            } else {
              W[-i0][i1] = MIN(MIN(MIN(W[-i0 + 1][i1], W[-i0][i1 - 1]), V[-i0][i1]), W[-i0][i1]);
            }
          }
        }
      }
    }
  }
}
*/

