int INT_MAX = 4;

void foo2(int n, int **m, int **s, int *p){
#pragma scop
	for (int L=2; L<n; L++) {
		for (int i=1; i<n-L+1; i++) {
			m[i][i+L-1] = INT_MAX;
			for (int k=i; k<=i+L-1-1; k++) {
				if (m[i][k] + m[k+1][i+L-1] + p[i-1]*p[k]*p[i+L-1] < m[i][i+L-1]){
					m[i][i+L-1] = m[i][k] + m[k+1][i+L-1] + p[i-1]*p[k]*p[i+L-1];
					s[i][i+L-1] = k;
				}
			}
		}
	}
#pragma endscop
}



//Tiles 2D 16x16:
/*
//dapt filename=./work_test.c size=16 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = floord(-n + 2, 16); w0 < floord(n - 1, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(0, w0 + 1); h0 <= (n + 16 * w0 + 15) / 32; h0 += 1) {
    for (int i0 = max(2, 16 * h0); i0 <= min(16 * h0 + 15, n + 16 * w0 - 16 * h0 + 15); i0 += 1) {
      for (int i1 = -16 * w0 + 16 * h0 - 15; i1 <= min(-16 * w0 + 16 * h0, n - i0); i1 += 1) {
        {
          m[i1][i0 + i1 - 1] = (INT_MAX);
          for (int i3 = i1; i3 < i0 + i1 - 1; i3 += 1) {
            if (((m[i1][i3] + m[i3 + 1][i0 + i1 - 1]) + ((p[i1 - 1] * p[i3]) * p[i0 + i1 - 1])) < m[i1][i0 + i1 - 1]) {
              m[i1][i0 + i1 - 1] = ((m[i1][i3] + m[i3 + 1][i0 + i1 - 1]) + ((p[i1 - 1] * p[i3]) * p[i0 + i1 - 1]));
              s[i1][i0 + i1 - 1] = (i3);
            }
          }
        }
      }
    }
  }
}
*/

//Tiles 2D 16x16 with timeline=2:
/*
//dapt filename=./work_test.c size=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 sizetime1=1 sizetime2=1 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = floord(-n + 2, 16); w0 < floord(n - 1, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(0, w0 + 1); h0 <= (n + 16 * w0 + 15) / 32; h0 += 1) {
    for (int t0 = max(max(max(8 * w0, 8 * w0 - 8 * h0 + 1), -n + 16 * h0 + n / 2), -n + n / 2 + 2); t0 <= min(8 * w0 + 15, 16 * w0 - 16 * h0 + n / 2 + 15); t0 += 1) {
      for (int i0 = max(max(2, 16 * h0), -16 * w0 + 16 * h0 + 2 * t0 - 15); i0 <= min(min(16 * h0 + 15, -16 * w0 + 16 * h0 + 2 * t0 + 1), t0 + (n + 1) / 2); i0 += 1) {
        for (int i1 = max(-16 * w0 + 16 * h0 - 15, -2 * t0 + i0 - 1); i1 <= min(min(-16 * w0 + 16 * h0, -2 * t0 + i0), n - i0); i1 += 1) {
          {
            m[i1][i0 + i1 - 1] = (INT_MAX);
            for (int i3 = i1; i3 < i0 + i1 - 1; i3 += 1) {
              if (((m[i1][i3] + m[i3 + 1][i0 + i1 - 1]) + ((p[i1 - 1] * p[i3]) * p[i0 + i1 - 1])) < m[i1][i0 + i1 - 1]) {
                m[i1][i0 + i1 - 1] = ((m[i1][i3] + m[i3 + 1][i0 + i1 - 1]) + ((p[i1 - 1] * p[i3]) * p[i0 + i1 - 1]));
                s[i1][i0 + i1 - 1] = (i3);
              }
            }
          }
        }
      }
    }
  }
}
 */

//Tiles 2D 16x16 with sequential tiles 4x4:
 /*
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=1 sizetime1=4 sizetime2=4 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = floord(-n + 2, 16); w0 < floord(n - 1, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(0, w0 + 1); h0 <= (n + 16 * w0 + 15) / 32; h0 += 1) {
    for (int t0 = max(max(4 * w0, 8 * h0 - (n + 3) / 4), 4 * h0 - (n + 1) / 4); t0 <= min(4 * w0 + 6, 8 * w0 - 8 * h0 + (n - 1) / 4 + 7); t0 += 1) {
      for (int i0 = max(max(2, 16 * h0), -16 * w0 + 16 * h0 + 4 * t0 - 12); i0 <= min(min(min(min(16 * h0 + 15, n + 16 * w0 - 16 * h0 + 15), -16 * w0 + 16 * h0 + 4 * t0 + 3), n - 16 * h0 + 4 * t0 + 3), 2 * t0 + n / 2 + 3); i0 += 1) {
        for (int i1 = -(i0 % 4) - 4 * t0 + i0 - 3; i1 <= min(n - i0, -(i0 % 4) - 4 * t0 + i0); i1 += 1) {
          {
            m[i1][i0 + i1 - 1] = (INT_MAX);
            for (int i3 = i1; i3 < i0 + i1 - 1; i3 += 1) {
              if (((m[i1][i3] + m[i3 + 1][i0 + i1 - 1]) + ((p[i1 - 1] * p[i3]) * p[i0 + i1 - 1])) < m[i1][i0 + i1 - 1]) {
                m[i1][i0 + i1 - 1] = ((m[i1][i3] + m[i3 + 1][i0 + i1 - 1]) + ((p[i1 - 1] * p[i3]) * p[i0 + i1 - 1]));
                s[i1][i0 + i1 - 1] = (i3);
              }
            }
          }
        }
      }
    }
  }
}
*/

