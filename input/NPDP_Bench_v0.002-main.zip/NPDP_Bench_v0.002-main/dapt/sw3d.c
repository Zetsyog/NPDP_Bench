int INT_MIN = 4;
int MAX(int, int);
int s(int, int);

void foo2(int N, int ***m1, int ***m2, int ***m3, int ***m4, int ***m5, int ***m6, int ***H, int *W, int *a, int *b, int *c){
#pragma scop
	for (int i=1; i <=N; i++)
		for (int j=1; j <=N; j++){
			for (int l=1; l<=N; l++){
				// Block S
				m1[i][j][l] = INT_MIN;
				for (int k=1; k <=i; k++)
					m1[i][j][l] = MAX(m1[i][j][l] ,H[i-k][j][l] - 2*W[k]);
	            m2[i][j][l] = INT_MIN;
	            for (int k=1; k <=j; k++)
	                m2[i][j][l] = MAX(m2[i][j][l], H[i][j-k][l] - 2*W[k]);
	            m3[i][j][l] = INT_MIN;
	            for (int k=1; k <=l; k++)
	                m3[i][j][l] = MAX(m3[i][j][l], H[i][j][l-k] - 2*W[k]);
	            m4[i][j][l] = INT_MIN;
	            for (int k=1; k <=min(i,j); k++)
	                m4[i][j][l] = MAX(m4[i][j][l], H[i-k][j-k][l] - W[k] + s(a[i], b[j]));
	            m5[i][j][l] = INT_MIN;
	            for (int k=1; k <=min(j,l); k++)
	                m5[i][j][l] = MAX(m5[i][j][l], H[i][j-k][l-k] - W[k] + s(b[j], c[l]));
	            m6[i][j][l] = INT_MIN;
	            for (int k=1; k <=min(i,l); k++)
	                m6[i][j][l] = MAX(m6[i][j][l], H[i-k][j][l-k] - W[k] + s(a[i], c[l]));
	            H[i][j][l] = MAX(0, MAX( H[i-1][j-1][l-1] + s(a[i], b[j]) + s(a[i], c[l]) + s(b[j], c[l]), MAX(m1[i][j][l], MAX(m2[i][j][l], MAX(m3[i][j][l], MAX(m4[i][j][l], MAX(m5[i][j][l], m6[i][j][l])))))));


	        }
	    }
#pragma endscop
}



//Tiles 3D 16x16x16:
/*
//dapt filename=./work_test.c size=16 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = 0; w0 <= floord(3 * N, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(0, w0 - (N + 8) / 8 + 1); h0 <= min(w0, N / 16); h0 += 1) {
    for (int h1 = max(0, w0 - h0 - (N + 16) / 16 + 1); h1 <= min(w0 - h0, N / 16); h1 += 1) {
      for (int i0 = max(1, 16 * h0); i0 <= min(N, 16 * h0 + 15); i0 += 1) {
        for (int i1 = max(1, 16 * h1); i1 <= min(N, 16 * h1 + 15); i1 += 1) {
          for (int i2 = max(1, 16 * w0 - 16 * h0 - 16 * h1); i2 <= min(N, 16 * w0 - 16 * h0 - 16 * h1 + 15); i2 += 1) {
            {
              m1[i0][i1][i2] = (INT_MIN);
              for (int i4 = 1; i4 <= i0; i4 += 1) {
                m1[i0][i1][i2] = MAX(m1[i0][i1][i2], H[i0 - i4][i1][i2] - (2 * W[i4]));
              }
              m2[i0][i1][i2] = (INT_MIN);
              for (int i4 = 1; i4 <= i1; i4 += 1) {
                m2[i0][i1][i2] = MAX(m2[i0][i1][i2], H[i0][i1 - i4][i2] - (2 * W[i4]));
              }
              m3[i0][i1][i2] = (INT_MIN);
              for (int i4 = 1; i4 <= i2; i4 += 1) {
                m3[i0][i1][i2] = MAX(m3[i0][i1][i2], H[i0][i1][i2 - i4] - (2 * W[i4]));
              }
              m4[i0][i1][i2] = (INT_MIN);
              for (int i4 = 1; i4 <= min(i0, i1); i4 += 1) {
                m4[i0][i1][i2] = MAX(m4[i0][i1][i2], (H[i0 - i4][i1 - i4][i2] - W[i4]) + s(a[i0], b[i1]));
              }
              if (i1 >= i0 + 1) {
                m5[i0][i1][i2] = (INT_MIN);
              } else {
                m5[i0][i1][i2] = (INT_MIN);
              }
              for (int i4 = 1; i4 <= min(i1, i2); i4 += 1) {
                m5[i0][i1][i2] = MAX(m5[i0][i1][i2], (H[i0][i1 - i4][i2 - i4] - W[i4]) + s(b[i1], c[i2]));
              }
              if (i2 >= i1 + 1) {
                m6[i0][i1][i2] = (INT_MIN);
              } else {
                m6[i0][i1][i2] = (INT_MIN);
              }
              for (int i4 = 1; i4 <= min(i0, i2); i4 += 1) {
                m6[i0][i1][i2] = MAX(m6[i0][i1][i2], (H[i0 - i4][i1][i2 - i4] - W[i4]) + s(a[i0], c[i2]));
              }
              if (i2 >= i0 + 1) {
                H[i0][i1][i2] = MAX(0, MAX(((H[i0 - 1][i1 - 1][i2 - 1] + s(a[i0], b[i1])) + s(a[i0], c[i2])) + s(b[i1], c[i2]), MAX(m1[i0][i1][i2], MAX(m2[i0][i1][i2], MAX(m3[i0][i1][i2], MAX(m4[i0][i1][i2], MAX(m5[i0][i1][i2], m6[i0][i1][i2])))))));
              } else {
                H[i0][i1][i2] = MAX(0, MAX(((H[i0 - 1][i1 - 1][i2 - 1] + s(a[i0], b[i1])) + s(a[i0], c[i2])) + s(b[i1], c[i2]), MAX(m1[i0][i1][i2], MAX(m2[i0][i1][i2], MAX(m3[i0][i1][i2], MAX(m4[i0][i1][i2], MAX(m5[i0][i1][i2], m6[i0][i1][i2])))))));
              }
            }
          }
        }
      }
    }
  }
}
*/

//Tiles 3D 16x16x16 with timeline=2:
/*
//dapt filename=./work_test.c size=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 sizetimetile=2 sizetime1=1 sizetime2=1 sizetime3=1 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = 0; w0 <= floord(3 * N, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(0, w0 - (N + 8) / 8 + 1); h0 <= min(w0, N / 16); h0 += 1) {
    for (int h1 = max(0, w0 - h0 - (N + 16) / 16 + 1); h1 <= min(w0 - h0, N / 16); h1 += 1) {
      for (int t0 = max(max(max(8 * w0, 8 * h0 + 1), 8 * h1 + 1), 8 * w0 - 8 * h0 - 8 * h1 + 1); t0 <= min(min(min(min(min(min(min(8 * w0 + 22, N + 8 * h0 + 7), N + 8 * h1 + 7), N + 8 * w0 - 8 * h0 - 8 * h1 + 7), N + N / 2), 8 * h0 + 8 * h1 + N / 2 + 15), 8 * w0 - 8 * h0 + N / 2 + 15), 8 * w0 - 8 * h1 + N / 2 + 15); t0 += 1) {
        for (int i0 = max(max(max(max(max(1, 16 * h0), -16 * w0 + 16 * h0 + 2 * t0 - 30), -N - 16 * w0 + 16 * h0 + 16 * h1 + 2 * t0 - 15), -N - 16 * h1 + 2 * t0 - 15), -2 * N + 2 * t0); i0 <= min(min(min(min(min(N, 16 * h0 + 15), 2 * t0 - 1), -16 * w0 + 16 * h0 + 16 * h1 + 2 * t0), -16 * h1 + 2 * t0), -16 * w0 + 16 * h0 + 2 * t0 + 1); i0 += 1) {
          for (int i1 = max(max(max(1, 16 * h1), -16 * w0 + 16 * h0 + 16 * h1 + 2 * t0 - i0 - 15), -N + 2 * t0 - i0); i1 <= min(min(min(N, 16 * h1 + 15), 2 * t0 - i0), -16 * w0 + 16 * h0 + 16 * h1 + 2 * t0 - i0 + 1); i1 += 1) {
            for (int i2 = max(max(1, 16 * w0 - 16 * h0 - 16 * h1), 2 * t0 - i0 - i1); i2 <= min(min(N, 16 * w0 - 16 * h0 - 16 * h1 + 15), 2 * t0 - i0 - i1 + 1); i2 += 1) {
              {
                m1[i0][i1][i2] = (INT_MIN);
                for (int i4 = 1; i4 <= i0; i4 += 1) {
                  m1[i0][i1][i2] = MAX(m1[i0][i1][i2], H[i0 - i4][i1][i2] - (2 * W[i4]));
                }
                m2[i0][i1][i2] = (INT_MIN);
                for (int i4 = 1; i4 <= i1; i4 += 1) {
                  m2[i0][i1][i2] = MAX(m2[i0][i1][i2], H[i0][i1 - i4][i2] - (2 * W[i4]));
                }
                m3[i0][i1][i2] = (INT_MIN);
                for (int i4 = 1; i4 <= i2; i4 += 1) {
                  m3[i0][i1][i2] = MAX(m3[i0][i1][i2], H[i0][i1][i2 - i4] - (2 * W[i4]));
                }
                m4[i0][i1][i2] = (INT_MIN);
                for (int i4 = 1; i4 <= min(i0, i1); i4 += 1) {
                  m4[i0][i1][i2] = MAX(m4[i0][i1][i2], (H[i0 - i4][i1 - i4][i2] - W[i4]) + s(a[i0], b[i1]));
                }
                if (i1 >= i0 + 1) {
                  m5[i0][i1][i2] = (INT_MIN);
                } else {
                  m5[i0][i1][i2] = (INT_MIN);
                }
                for (int i4 = 1; i4 <= min(i1, i2); i4 += 1) {
                  m5[i0][i1][i2] = MAX(m5[i0][i1][i2], (H[i0][i1 - i4][i2 - i4] - W[i4]) + s(b[i1], c[i2]));
                }
                if (i2 >= i1 + 1) {
                  m6[i0][i1][i2] = (INT_MIN);
                } else {
                  m6[i0][i1][i2] = (INT_MIN);
                }
                for (int i4 = 1; i4 <= min(i0, i2); i4 += 1) {
                  m6[i0][i1][i2] = MAX(m6[i0][i1][i2], (H[i0 - i4][i1][i2 - i4] - W[i4]) + s(a[i0], c[i2]));
                }
                if (i2 >= i0 + 1) {
                  H[i0][i1][i2] = MAX(0, MAX(((H[i0 - 1][i1 - 1][i2 - 1] + s(a[i0], b[i1])) + s(a[i0], c[i2])) + s(b[i1], c[i2]), MAX(m1[i0][i1][i2], MAX(m2[i0][i1][i2], MAX(m3[i0][i1][i2], MAX(m4[i0][i1][i2], MAX(m5[i0][i1][i2], m6[i0][i1][i2])))))));
                } else {
                  H[i0][i1][i2] = MAX(0, MAX(((H[i0 - 1][i1 - 1][i2 - 1] + s(a[i0], b[i1])) + s(a[i0], c[i2])) + s(b[i1], c[i2]), MAX(m1[i0][i1][i2], MAX(m2[i0][i1][i2], MAX(m3[i0][i1][i2], MAX(m4[i0][i1][i2], MAX(m5[i0][i1][i2], m6[i0][i1][i2])))))));
                }
              }
            }
          }
        }
      }
    }
  }
}
 */

//Tiles 3D 16x16x16 with sequential tiles 4x4x4:
 /*
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 sizetimetile=1 sizetime1=4 sizetime2=4 sizetime3=4 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = 0; w0 <= floord(3 * N, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(0, w0 - (N + 8) / 8 + 1); h0 <= min(w0, N / 16); h0 += 1) {
    for (int h1 = max(0, w0 - h0 - (N + 16) / 16 + 1); h1 <= min(w0 - h0, N / 16); h1 += 1) {
      for (int t0 = 4 * w0; t0 <= min(min(min(min(min(min(min(4 * w0 + 9, 4 * h1 + N / 2 + 3), 4 * h0 + N / 2 + 3), 4 * w0 - 4 * h0 - 4 * h1 + N / 2 + 3), N - (N + 3) / 4), 4 * h0 + 4 * h1 + N / 4 + 6), 4 * w0 - 4 * h0 + N / 4 + 6), 4 * w0 - 4 * h1 + N / 4 + 6); t0 += 1) {
        for (int i0 = max(max(max(max(max(1, 16 * h0), -16 * w0 + 16 * h0 + 4 * t0 - 24), -N - 16 * w0 + 16 * h0 + 16 * h1 + 4 * t0 - 12), -N - 16 * h1 + 4 * t0 - 12), -2 * N + 4 * t0); i0 <= min(min(N, 16 * h0 + 15), -16 * w0 + 16 * h0 + 4 * t0 + 3); i0 += 1) {
          if (N + 16 * h1 + i0 + 12 >= (i0 % 4) + 4 * t0) {
            for (int i1 = max(max(max(1, 16 * h1), -16 * w0 + 16 * h0 + 16 * h1 + 4 * t0 - i0 - 12), (i0 % 4) - N + 4 * t0 - i0); i1 <= min(min(N, 16 * h1 + 15), -16 * w0 + 16 * h0 + 16 * h1 + 4 * t0 - i0 + 6); i1 += 1) {
              for (int i2 = max(max(1, 16 * w0 - 16 * h0 - 16 * h1), (i0 % 4) + (i1 % 4) + 4 * t0 - i0 - i1); i2 <= min(min(N, 16 * w0 - 16 * h0 - 16 * h1 + 15), (i0 % 4) + (i1 % 4) + 4 * t0 - i0 - i1 + 3); i2 += 1) {
                {
                  m1[i0][i1][i2] = (INT_MIN);
                  for (int i4 = 1; i4 <= i0; i4 += 1) {
                    m1[i0][i1][i2] = MAX(m1[i0][i1][i2], H[i0 - i4][i1][i2] - (2 * W[i4]));
                  }
                  m2[i0][i1][i2] = (INT_MIN);
                  for (int i4 = 1; i4 <= i1; i4 += 1) {
                    m2[i0][i1][i2] = MAX(m2[i0][i1][i2], H[i0][i1 - i4][i2] - (2 * W[i4]));
                  }
                  m3[i0][i1][i2] = (INT_MIN);
                  for (int i4 = 1; i4 <= i2; i4 += 1) {
                    m3[i0][i1][i2] = MAX(m3[i0][i1][i2], H[i0][i1][i2 - i4] - (2 * W[i4]));
                  }
                  m4[i0][i1][i2] = (INT_MIN);
                  for (int i4 = 1; i4 <= min(i0, i1); i4 += 1) {
                    m4[i0][i1][i2] = MAX(m4[i0][i1][i2], (H[i0 - i4][i1 - i4][i2] - W[i4]) + s(a[i0], b[i1]));
                  }
                  if (i1 >= i0 + 1) {
                    m5[i0][i1][i2] = (INT_MIN);
                  } else {
                    m5[i0][i1][i2] = (INT_MIN);
                  }
                  for (int i4 = 1; i4 <= min(i1, i2); i4 += 1) {
                    m5[i0][i1][i2] = MAX(m5[i0][i1][i2], (H[i0][i1 - i4][i2 - i4] - W[i4]) + s(b[i1], c[i2]));
                  }
                  if (i2 >= i1 + 1) {
                    m6[i0][i1][i2] = (INT_MIN);
                  } else {
                    m6[i0][i1][i2] = (INT_MIN);
                  }
                  for (int i4 = 1; i4 <= min(i0, i2); i4 += 1) {
                    m6[i0][i1][i2] = MAX(m6[i0][i1][i2], (H[i0 - i4][i1][i2 - i4] - W[i4]) + s(a[i0], c[i2]));
                  }
                  if (i2 >= i0 + 1) {
                    H[i0][i1][i2] = MAX(0, MAX(((H[i0 - 1][i1 - 1][i2 - 1] + s(a[i0], b[i1])) + s(a[i0], c[i2])) + s(b[i1], c[i2]), MAX(m1[i0][i1][i2], MAX(m2[i0][i1][i2], MAX(m3[i0][i1][i2], MAX(m4[i0][i1][i2], MAX(m5[i0][i1][i2], m6[i0][i1][i2])))))));
                  } else {
                    H[i0][i1][i2] = MAX(0, MAX(((H[i0 - 1][i1 - 1][i2 - 1] + s(a[i0], b[i1])) + s(a[i0], c[i2])) + s(b[i1], c[i2]), MAX(m1[i0][i1][i2], MAX(m2[i0][i1][i2], MAX(m3[i0][i1][i2], MAX(m4[i0][i1][i2], MAX(m5[i0][i1][i2], m6[i0][i1][i2])))))));
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
*/

