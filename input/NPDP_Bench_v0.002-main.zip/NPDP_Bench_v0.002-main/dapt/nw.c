int INT_MIN = 3;
int MAX(int, int);
int s(int, int);

void foo2(int N, int **m1, int **m2, int **F, int *W, int *a, int *b){
#pragma scop
	for (int i=1; i <=N; i++)
		for (int j=1; j <=N; j++){
			// Block S
	        m1[i][j] = INT_MIN;
	        for (int k=1; k <=i; k++)
	            m1[i][j] = MAX(m1[i][j] ,F[i-k][j] - W[k]);
	        m2[i][j] = INT_MIN;
	        for (int k=1; k <=j; k++)
	            m2[i][j] = MAX(m2[i][j] ,F[i][j-k] - W[k]);
	        F[i][j] = MAX(0, MAX( F[i-1][j-1] + s(a[i], b[i]), MAX(m1[i][j], m2[i][j])));
	    }
#pragma endscop
}

//Tiles 2D 16x16:
/*
//dapt filename=./work_test.c size=16 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = 0; w0 <= floord(N, 8); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(0, w0 - (N + 16) / 16 + 1); h0 <= min(w0, N / 16); h0 += 1) {
    for (int i0 = max(1, 16 * h0); i0 <= min(N, 16 * h0 + 15); i0 += 1) {
      for (int i1 = max(1, 16 * w0 - 16 * h0); i1 <= min(N, 16 * w0 - 16 * h0 + 15); i1 += 1) {
        {
          m1[i0][i1] = (INT_MIN);
          for (int i3 = 1; i3 <= i0; i3 += 1) {
            m1[i0][i1] = MAX(m1[i0][i1], F[i0 - i3][i1] - W[i3]);
          }
          m2[i0][i1] = (INT_MIN);
          for (int i3 = 1; i3 <= i1; i3 += 1) {
            m2[i0][i1] = MAX(m2[i0][i1], F[i0][i1 - i3] - W[i3]);
          }
          F[i0][i1] = MAX(0, MAX(F[i0 - 1][i1 - 1] + s(a[i0], b[i0]), MAX(m1[i0][i1], m2[i0][i1])));
        }
      }
    }
  }
}
*/

//Tiles 2D 16x16 with timeline=2:
/*
//dapt filename=./work_test.c size=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 method=2 --debug-print-on
 //or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 sizetime1=1 sizetime2=1 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = 0; w0 <= floord(N, 8); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(0, w0 - (N + 16) / 16 + 1); h0 <= min(w0, N / 16); h0 += 1) {
    for (int t0 = max(1, 8 * w0); t0 <= min(min(min(N, 8 * w0 + 15), 8 * h0 + (N + 1) / 2 + 7), 8 * w0 - 8 * h0 + (N + 1) / 2 + 7); t0 += 1) {
      for (int i0 = max(max(max(1, 16 * h0), -16 * w0 + 16 * h0 + 2 * t0 - 15), -N + 2 * t0); i0 <= min(min(min(N, 16 * h0 + 15), 2 * t0), -16 * w0 + 16 * h0 + 2 * t0 + 1); i0 += 1) {
        for (int i1 = max(max(1, 16 * w0 - 16 * h0), 2 * t0 - i0); i1 <= min(min(N, 16 * w0 - 16 * h0 + 15), 2 * t0 - i0 + 1); i1 += 1) {
          {
            m1[i0][i1] = (INT_MIN);
            for (int i3 = 1; i3 <= i0; i3 += 1) {
              m1[i0][i1] = MAX(m1[i0][i1], F[i0 - i3][i1] - W[i3]);
            }
            m2[i0][i1] = (INT_MIN);
            for (int i3 = 1; i3 <= i1; i3 += 1) {
              m2[i0][i1] = MAX(m2[i0][i1], F[i0][i1 - i3] - W[i3]);
            }
            F[i0][i1] = MAX(0, MAX(F[i0 - 1][i1 - 1] + s(a[i0], b[i0]), MAX(m1[i0][i1], m2[i0][i1])));
          }
        }
      }
    }
  }
}
 */

//Tiles 2D 16x16 with sequential tiles 4x4:
 /*
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=1 sizetime1=4 sizetime2=4 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = 0; w0 <= floord(N, 8); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(0, w0 - (N + 16) / 16 + 1); h0 <= min(w0, N / 16); h0 += 1) {
    for (int t0 = 4 * w0; t0 <= min(min(min(4 * w0 + 6, N / 2), 4 * h0 + N / 4 + 3), 4 * w0 - 4 * h0 + N / 4 + 3); t0 += 1) {
      for (int i0 = max(max(max(1, 16 * h0), -16 * w0 + 16 * h0 + 4 * t0 - 12), -N + 4 * t0); i0 <= min(min(N, 16 * h0 + 15), -16 * w0 + 16 * h0 + 4 * t0 + 3); i0 += 1) {
        for (int i1 = max(1, (i0 % 4) + 4 * t0 - i0); i1 <= min(N, (i0 % 4) + 4 * t0 - i0 + 3); i1 += 1) {
          {
            m1[i0][i1] = (INT_MIN);
            for (int i3 = 1; i3 <= i0; i3 += 1) {
              m1[i0][i1] = MAX(m1[i0][i1], F[i0 - i3][i1] - W[i3]);
            }
            m2[i0][i1] = (INT_MIN);
            for (int i3 = 1; i3 <= i1; i3 += 1) {
              m2[i0][i1] = MAX(m2[i0][i1], F[i0][i1 - i3] - W[i3]);
            }
            F[i0][i1] = MAX(0, MAX(F[i0 - 1][i1 - 1] + s(a[i0], b[i0]), MAX(m1[i0][i1], m2[i0][i1])));
          }
        }
      }
    }
  }
}
*/

