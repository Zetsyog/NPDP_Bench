int INT_MAX = 4;
int MIN(int, int);

void foo2(int N, int **table){
#pragma scop
	for (int gap = 0; gap < N; gap++) {
		for (int j = gap; j < N; j++)    // i = j - gap
	    {
			if (gap < 2)
				table[j-gap][j] = 0.0;
			else
			{
				table[j-gap][j] = INT_MAX;
				for (int k = j-gap+1; k < j; k++)
				{
					table[j-gap][j]  = MIN(table[j-gap][j], table[j-gap][k] + table[k][j] + cost(j-gap,j,k));
				}
			}
	    }
	}
#pragma endscop
}



//Tiles 2D 16x16:
/*
//dapt filename=./work_test.c size=16 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))

if (N >= 3) {
  for (int w0 = 0; w0 <= (N - 1) / 8; w0 += 1) {
    {
      for (int i0 = 0; i0 <= 1; i0 += 1) {
        for (int i1 = max(16 * w0, i0); i1 <= min(N - 1, 16 * w0 + 15); i1 += 1) {
          table[-i0 + i1][i1] = 0.0;
        }
      }
      #pragma omp parallel for
      for (int h0 = max(0, w0 - (N + 15) / 16 + 1); h0 <= w0 / 2; h0 += 1) {
        for (int i0 = max(2, 16 * h0); i0 <= min(N - 1, 16 * h0 + 15); i0 += 1) {
          for (int i1 = max(16 * w0 - 16 * h0, i0); i1 <= min(N - 1, 16 * w0 - 16 * h0 + 15); i1 += 1) {
            {
              table[-i0 + i1][i1] = (INT_MAX);
              for (int i4 = -i0 + i1 + 1; i4 < i1; i4 += 1) {
                table[-i0 + i1][i1] = MIN(table[-i0 + i1][i1], (table[-i0 + i1][i4] + table[i4][i1]) + cost((-i0 + i1), (i1), (i4)));
              }
            }
          }
        }
      }
    }
  }
} else {
  for (int i0 = 0; i0 < N; i0 += 1) {
    for (int i1 = i0; i1 < N; i1 += 1) {
      table[-i0 + i1][i1] = 0.0;
    }
  }
}
*/

//Tiles 2D 16x16 with timeline=2:
/*
//dapt filename=./work_test.c size=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 sizetime1=1 sizetime2=1 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))

if (N >= 3) {
  for (int w0 = 0; w0 <= (N - 1) / 8; w0 += 1) {
    #pragma omp parallel for
    for (int h0 = max(0, w0 - (N + 15) / 16 + 1); h0 <= w0 / 2; h0 += 1) {
      {
        if (h0 == 0) {
          for (int i0 = 0; i0 <= min(1, 8 * w0); i0 += 1) {
            for (int i1 = 16 * w0; i1 <= min(N - 1, 16 * w0 - i0 + 1); i1 += 1) {
              table[-i0 + i1][i1] = 0.0;
            }
          }
          if (w0 == 0) {
            for (int i0 = 0; i0 <= 1; i0 += 1) {
              for (int i1 = -i0 + 2; i1 <= min(N - 1, -i0 + 3); i1 += 1) {
                table[-i0 + i1][i1] = 0.0;
              }
            }
          }
        }
        for (int t0 = max(max(2, 8 * w0), 8 * w0 - 8 * h0 + 1); t0 <= min(min(N - 1, 8 * w0 + 15), 8 * h0 + N / 2 + 7); t0 += 1) {
          {
            if (h0 == 0) {
              for (int i0 = max(max(0, -16 * w0 + 2 * t0 - 15), -N + 2 * t0 + 1); i0 <= 1; i0 += 1) {
                for (int i1 = 2 * t0 - i0; i1 <= min(min(N - 1, 16 * w0 + 15), 2 * t0 - i0 + 1); i1 += 1) {
                  table[-i0 + i1][i1] = 0.0;
                }
              }
            }
            for (int i0 = max(max(max(2, 16 * h0), -16 * w0 + 16 * h0 + 2 * t0 - 15), -N + 2 * t0 + 1); i0 <= min(min(16 * h0 + 15, t0), -16 * w0 + 16 * h0 + 2 * t0 + 1); i0 += 1) {
              for (int i1 = max(16 * w0 - 16 * h0, 2 * t0 - i0); i1 <= min(min(N - 1, 16 * w0 - 16 * h0 + 15), 2 * t0 - i0 + 1); i1 += 1) {
                {
                  table[-i0 + i1][i1] = (INT_MAX);
                  for (int i4 = -i0 + i1 + 1; i4 < i1; i4 += 1) {
                    table[-i0 + i1][i1] = MIN(table[-i0 + i1][i1], (table[-i0 + i1][i4] + table[i4][i1]) + cost((-i0 + i1), (i1), (i4)));
                  }
                }
              }
            }
          }
        }
      }
    }
  }
} else {
  for (int t0 = 0; t0 < N; t0 += 1) {
    for (int i1 = t0; i1 < N; i1 += 1) {
      table[-t0 + i1][i1] = 0.0;
    }
  }
}
 */

//Tiles 2D 16x16 with sequential tiles 4x4:
 /*
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=1 sizetime1=4 sizetime2=4 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))

if (N >= 3) {
  for (int w0 = 0; w0 <= (N - 1) / 8; w0 += 1) {
    #pragma omp parallel for
    for (int h0 = max(0, w0 - (N + 15) / 16 + 1); h0 <= w0 / 2; h0 += 1) {
      for (int t0 = 4 * w0; t0 <= min(min(4 * w0 + 6, (N + 1) / 2 - 1), 4 * h0 + (N - 1) / 4 + 3); t0 += 1) {
        {
          if (h0 == 0 && 4 * w0 + 3 >= t0) {
            for (int i0 = 0; i0 <= 1; i0 += 1) {
              for (int i1 = max(4 * t0, i0); i1 <= min(N - 1, 4 * t0 + 3); i1 += 1) {
                table[-i0 + i1][i1] = 0.0;
              }
            }
          }
          for (int i0 = max(max(max(2, 16 * h0), -16 * w0 + 16 * h0 + 4 * t0 - 12), -N + 4 * t0 + 1); i0 <= min(min(min(N - 1, 16 * h0 + 15), -16 * w0 + 16 * h0 + 4 * t0 + 3), 2 * t0 + 3); i0 += 1) {
            for (int i1 = max(i0, (i0 % 4) + 4 * t0 - i0); i1 <= min(N - 1, (i0 % 4) + 4 * t0 - i0 + 3); i1 += 1) {
              {
                table[-i0 + i1][i1] = (INT_MAX);
                for (int i4 = -i0 + i1 + 1; i4 < i1; i4 += 1) {
                  table[-i0 + i1][i1] = MIN(table[-i0 + i1][i1], (table[-i0 + i1][i4] + table[i4][i1]) + cost((-i0 + i1), (i1), (i4)));
                }
              }
            }
          }
        }
      }
    }
  }
} else {
  for (int i0 = 0; i0 < N; i0 += 1) {
    for (int i1 = i0; i1 < N; i1 += 1) {
      table[-i0 + i1][i1] = 0.0;
    }
  }
}
*/

