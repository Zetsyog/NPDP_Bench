int can_pair(int, int, int);
int printf(int, int);

void foo2(int N, int **S, int RNA, int *z){
#pragma scop
	for (int i = N-1; i >= 0; i--) {
		if(i % 100==0)
			//printf("%i \n", i); //pet has a problem with "" -> temporary replace with:
			//printf(100, i); //but results tstile.h, tilecorr.h, pluto.h, nucc17.cpp skips printf call
		for (int j = i+1; j < N; j++) {
			for (int k = 0; k < j-i; k++) {
				S[i][j] = max(S[i][k+i] + S[k+i+1][j], S[i][j]);
			}
			for (int k = 0; k < 1; k++) {
				S[i][j] = max(S[i][j], S[i+1][j-1]  + can_pair(RNA, i, j));
			}
		}


	}
#pragma endscop
}



//Tiles 2D 16x16:
/*
//dapt filename=./work_test.c size=16 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))

if (N >= 2) {
  for (int w0 = max(-1, -((N + 10) / 16)); w0 <= (N - 1) / 16; w0 += 1) {
    #pragma omp parallel for
    for (int h0 = max(w0 - (N + 15) / 16 + 1, -((N + 10) / 16)); h0 <= 0; h0 += 1) {
      if (4 * h0 + 25 * ((-4 * h0 + 21) / 25) <= 0) {
        for (int i1 = max(16 * w0 - 16 * h0, -(4 * ((-4 * h0 + 25) % 25)) - 16 * h0 + 1); i1 <= min(N - 1, 16 * w0 - 16 * h0 + 15); i1 += 1) {
          {
            for (int i3 = 0; i3 < i1 - 100 * ((-4 * h0 + 21) / 25); i3 += 1) {
              S[-(4 * (-4 * h0 % 25)) - 16 * h0][i1] = max(S[-(4 * (-4 * h0 % 25)) - 16 * h0][-(4 * (-4 * h0 % 25)) - 16 * h0 + i3] + S[-(4 * (-4 * h0 % 25)) - 16 * h0 + i3 + 1][i1], S[-(4 * (-4 * h0 % 25)) - 16 * h0][i1]);
            }
            S[-(4 * (-4 * h0 % 25)) - 16 * h0][i1] = max(S[-(4 * (-4 * h0 % 25)) - 16 * h0][i1], S[-(4 * (-4 * h0 % 25)) - 16 * h0 + 1][i1 - 1] + can_pair((RNA), (-(4 * (-4 * h0 % 25)) - 16 * h0), (i1)));
          }
        }
      }
    }
  }
}
*/

//Tiles 2D 16x16 with timeline=2:
/*
//dapt filename=./work_test.c size=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 sizetime1=1 sizetime2=1 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))

if (N >= 2) {
  for (int w0 = max(-1, -((N + 10) / 16)); w0 <= (N - 1) / 16; w0 += 1) {
    #pragma omp parallel for
    for (int h0 = max(w0 - (N + 15) / 16 + 1, -((N + 10) / 16)); h0 <= 0; h0 += 1) {
      if (4 * h0 + 25 * ((-4 * h0 + 21) / 25) <= 0) {
        for (int t0 = max(0, 2 * ((-4 * h0 + 25) % 25) + 8 * w0); t0 <= min(2 * ((-4 * h0 + 25) % 25) + 8 * w0 + 7, 2 * ((-4 * h0 + 25) % 25) + 8 * h0 + (N + 1) / 2 - 1); t0 += 1) {
          for (int i1 = max(-(4 * ((-4 * h0 + 25) % 25)) - 16 * h0 + 2 * t0, -(4 * ((-4 * h0 + 25) % 25)) - 16 * h0 + 1); i1 < min(N, -(4 * ((-4 * h0 + 25) % 25)) - 16 * h0 + 2 * t0 + 2); i1 += 1) {
            {
              for (int i3 = 0; i3 < i1 - 100 * ((-4 * h0 + 21) / 25); i3 += 1) {
                S[-(4 * (-4 * h0 % 25)) - 16 * h0][i1] = max(S[-(4 * (-4 * h0 % 25)) - 16 * h0][-(4 * (-4 * h0 % 25)) - 16 * h0 + i3] + S[-(4 * (-4 * h0 % 25)) - 16 * h0 + i3 + 1][i1], S[-(4 * (-4 * h0 % 25)) - 16 * h0][i1]);
              }
              S[-(4 * (-4 * h0 % 25)) - 16 * h0][i1] = max(S[-(4 * (-4 * h0 % 25)) - 16 * h0][i1], S[-(4 * (-4 * h0 % 25)) - 16 * h0 + 1][i1 - 1] + can_pair((RNA), (-(4 * (-4 * h0 % 25)) - 16 * h0), (i1)));
            }
          }
        }
      }
    }
  }
}
 */

//Tiles 2D 16x16 with sequential tiles 2x4:
 /*
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=1 sizetime1=2 sizetime2=4 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))

if (N >= 2) {
  for (int w0 = max(-1, -((N + 10) / 16)); w0 <= (N - 1) / 16; w0 += 1) {
    #pragma omp parallel for
    for (int h0 = max(w0 - (N + 15) / 16 + 1, -((N + 10) / 16)); h0 <= 0; h0 += 1) {
      if ((-4 * h0 + 25) % 25 <= 3) {
        for (int t0 = max(((-4 * h0 + 25) % 25) + 4 * h0, 2 * ((-4 * h0 + 25) % 25) + 4 * w0 + 4 * h0); t0 <= min(2 * ((-4 * h0 + 25) % 25) + 4 * w0 + 4 * h0 + 3, 2 * ((-4 * h0 + 25) % 25) + 8 * h0 + (N - 1) / 4); t0 += 1) {
          for (int i1 = max(-(8 * ((-4 * h0 + 25) % 25)) - 32 * h0 + 4 * t0, -(4 * ((-4 * h0 + 25) % 25)) - 16 * h0 + 1); i1 < min(N, -(8 * ((-4 * h0 + 25) % 25)) - 32 * h0 + 4 * t0 + 4); i1 += 1) {
            {
              for (int i3 = 0; i3 <= 4 * ((-4 * h0 + 25) % 25) + 16 * h0 + i1 - 1; i3 += 1) {
                S[-(4 * (-4 * h0 % 25)) - 16 * h0][i1] = max(S[-(4 * (-4 * h0 % 25)) - 16 * h0][-(4 * (-4 * h0 % 25)) - 16 * h0 + i3] + S[-(4 * (-4 * h0 % 25)) - 16 * h0 + i3 + 1][i1], S[-(4 * (-4 * h0 % 25)) - 16 * h0][i1]);
              }
              S[-(4 * (-4 * h0 % 25)) - 16 * h0][i1] = max(S[-(4 * (-4 * h0 % 25)) - 16 * h0][i1], S[-(4 * (-4 * h0 % 25)) - 16 * h0 + 1][i1 - 1] + can_pair((RNA), (-(4 * (-4 * h0 % 25)) - 16 * h0), (i1)));
            }
          }
        }
      }
    }
  }
}
*/

