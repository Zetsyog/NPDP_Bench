
void foo2(int N, int l, int **Q, int **Qbp, int **Pbp, int **Pu, int ERT){
#pragma scop
	for(int i=N-1; i>=0; i--){
		for(int j=i+1; j<N; j++){
	       Pu[i][j] = (Q[0][i]*Q[j][N-1]*1)/Q[0][N-1];
	       for(int p=0; p<i; p++){
	    	   for(int q=j+1; q<N; q++){
	    		   Pu[i][j] += (Pbp[p][q] * ERT * Q[p+1][i] * 1 * Q[j+1][q-1]) /  (Qbp[p][q] ==0 ? 1 : Qbp[p][q]);
	    	   }
	       }
		}
	}
#pragma endscop
}

//Tiles 3D 16x16x16:
/*
//dapt filename=./work_test.c size=16 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))

if (N >= 2) {
  for (int w0 = max(-1, -((N + 13) / 16)); w0 <= (N - 1) / 16; w0 += 1) {
    {
      #pragma omp parallel for
      for (int h0 = -((N + 12) / 16); h0 <= w0 - (N + 15) / 16; h0 += 1) {
        for (int h1 = max(w0 + 1, -h0 - 1); h1 <= (N - 2) / 16; h1 += 1) {
          for (int i0 = max(max(-N + 3, 16 * h0), -16 * h1 - 14); i0 <= 16 * h0 + 15; i0 += 1) {
            for (int i1 = max(16 * h1, -i0 + 1); i1 <= min(N - 2, 16 * h1 + 15); i1 += 1) {
              for (int i3 = 16 * w0 - 16 * h0 - 16 * h1; i3 <= min(16 * w0 - 16 * h0 - 16 * h1 + 15, -i0 - 1); i3 += 1) {
                for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                  Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                }
              }
            }
          }
        }
      }
      #pragma omp parallel for
      for (int h0 = max(w0 - (N + 15) / 16 + 1, -((N + 13) / 16)); h0 <= min(0, w0); h0 += 1) {
        {
          for (int h1 = max(w0 + 1, -h0 - 1); h1 < w0 - h0; h1 += 1) {
            for (int i0 = max(16 * h0, -16 * h1 - 14); i0 <= 16 * h0 + 15; i0 += 1) {
              for (int i1 = max(16 * h1, -i0 + 1); i1 <= 16 * h1 + 15; i1 += 1) {
                for (int i3 = 16 * w0 - 16 * h0 - 16 * h1; i3 <= min(16 * w0 - 16 * h0 - 16 * h1 + 15, -i0 - 1); i3 += 1) {
                  for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                    Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                  }
                }
              }
            }
          }
          for (int i0 = max(max(-N + 2, -16 * w0 + 16 * h0 - 14), 16 * h0); i0 <= min(0, 16 * h0 + 15); i0 += 1) {
            for (int i1 = max(16 * w0 - 16 * h0, -i0 + 1); i1 <= min(N - 1, 16 * w0 - 16 * h0 + 15); i1 += 1) {
              {
                Pu[-i0][i1] = (((Q[0][-i0] * Q[i1][N - 1]) * 1) / Q[0][N - 1]);
                for (int i3 = 0; i3 <= min(15, -i0 - 1); i3 += 1) {
                  for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                    Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
*/

//Tiles 3D 16x16x16 with timeline=2:
/*
//dapt filename=./work_test.c size=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 sizetimetile=2 sizetime1=1 sizetime2=1 sizetime3=1 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))

if (N >= 2) {
  for (int w0 = max(-1, -((N + 13) / 16)); w0 <= (N - 1) / 16; w0 += 1) {
    {
      #pragma omp parallel for
      for (int h0 = -((N + 12) / 16); h0 <= w0 - (N + 15) / 16; h0 += 1) {
        for (int h1 = max(w0 + 1, -h0 - 1); h1 <= (N - 2) / 16; h1 += 1) {
          for (int t0 = max(8 * w0, 8 * w0 - 8 * h0 - 8 * h1); t0 <= min(min(min(8 * w0 + 22, 8 * h1 + 7), 8 * w0 - 8 * h1 + N / 2 + 14), (N + 1) / 2 - 2); t0 += 1) {
            for (int i0 = max(max(max(max(-N + 3, 16 * h0), -16 * h1 - 14), -16 * w0 + 16 * h0 + 2 * t0 - 30), -N - 16 * w0 + 16 * h0 + 16 * h1 + 2 * t0 - 13); i0 <= min(16 * h0 + 15, -16 * w0 + 16 * h0 + 2 * t0 + 1); i0 += 1) {
              for (int i1 = max(max(max(16 * h1, 2 * t0 + 1), -16 * w0 + 16 * h0 + 16 * h1 + 2 * t0 - i0 - 15), -i0 + 1); i1 <= min(min(N - 2, 16 * h1 + 15), -16 * w0 + 16 * h0 + 16 * h1 + 2 * t0 - i0 + 1); i1 += 1) {
                for (int i3 = max(16 * w0 - 16 * h0 - 16 * h1, 2 * t0 - i0 - i1); i3 <= min(min(16 * w0 - 16 * h0 - 16 * h1 + 15, -i0 - 1), 2 * t0 - i0 - i1 + 1); i3 += 1) {
                  for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                    Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                  }
                }
              }
            }
          }
        }
      }
      #pragma omp parallel for
      for (int h0 = max(w0 - (N + 15) / 16 + 1, -((N + 13) / 16)); h0 <= min(0, w0); h0 += 1) {
        {
          for (int h1 = max(w0 + 1, -h0 - 1); h1 < w0 - h0; h1 += 1) {
            for (int t0 = max(8 * w0, 8 * w0 - 8 * h0 - 8 * h1); t0 <= min(8 * w0 + 22, 8 * h1 + 7); t0 += 1) {
              for (int i0 = max(max(16 * h0, -16 * h1 - 14), -16 * w0 + 16 * h0 + 2 * t0 - 30); i0 <= min(16 * h0 + 15, -16 * w0 + 16 * h0 + 2 * t0 + 1); i0 += 1) {
                for (int i1 = max(max(max(16 * h1, 2 * t0 + 1), -16 * w0 + 16 * h0 + 16 * h1 + 2 * t0 - i0 - 15), -i0 + 1); i1 <= min(16 * h1 + 15, -16 * w0 + 16 * h0 + 16 * h1 + 2 * t0 - i0 + 1); i1 += 1) {
                  for (int i3 = max(16 * w0 - 16 * h0 - 16 * h1, 2 * t0 - i0 - i1); i3 <= min(min(16 * w0 - 16 * h0 - 16 * h1 + 15, -i0 - 1), 2 * t0 - i0 - i1 + 1); i3 += 1) {
                    for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                      Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                    }
                  }
                }
              }
            }
          }
          for (int t0 = max(0, 8 * w0); t0 <= min(min(min(8 * w0 + 15, 8 * w0 - 8 * h0 + 7), 8 * h0 + N / 2 + 7), (N + 1) / 2 - 1); t0 += 1) {
            {
              for (int i0 = max(max(max(-N + 3, -16 * w0 + 16 * h0 - 14), 16 * h0), -N + 2 * t0 - 13); i0 < -16 * w0 + 16 * h0 + 2 * t0 - 15; i0 += 1) {
                for (int i1 = max(max(2 * t0 + 1, 2 * t0 - i0 - 15), -i0 + 1); i1 <= min(N - 2, 16 * w0 - 16 * h0 + 15); i1 += 1) {
                  for (int i3 = 2 * t0 - i0 - i1; i3 <= min(min(15, -i0 - 1), 2 * t0 - i0 - i1 + 1); i3 += 1) {
                    for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                      Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                    }
                  }
                }
              }
              for (int i0 = max(max(-N + 3, 16 * h0), -16 * w0 + 16 * h0 + 2 * t0 - 15); i0 <= -N + 2 * t0; i0 += 1) {
                for (int i1 = max(max(16 * w0 - 16 * h0, 2 * t0 + 1), -i0 + 1); i1 < N - 1; i1 += 1) {
                  for (int i3 = 2 * t0 - i0 - i1; i3 <= min(min(15, -i0 - 1), 2 * t0 - i0 - i1 + 1); i3 += 1) {
                    for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                      Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                    }
                  }
                }
              }
              for (int i0 = max(max(max(max(-N + 2, -16 * w0 + 16 * h0 - 14), 16 * h0), -16 * w0 + 16 * h0 + 2 * t0 - 15), -N + 2 * t0 + 1); i0 <= min(min(0, 16 * h0 + 15), -16 * w0 + 16 * h0 + 2 * t0 + 1); i0 += 1) {
                {
                  for (int i1 = max(max(16 * w0 - 16 * h0, 2 * t0 + 1), -i0 + 1); i1 < 2 * t0 - i0; i1 += 1) {
                    for (int i3 = 2 * t0 - i0 - i1; i3 <= min(min(15, -i0 - 1), 2 * t0 - i0 - i1 + 1); i3 += 1) {
                      for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                        Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                      }
                    }
                  }
                  for (int i1 = max(max(16 * w0 - 16 * h0, 2 * t0 - i0), -i0 + 1); i1 <= min(min(N - 1, 16 * w0 - 16 * h0 + 15), 2 * t0 - i0 + 1); i1 += 1) {
                    {
                      Pu[-i0][i1] = (((Q[0][-i0] * Q[i1][N - 1]) * 1) / Q[0][N - 1]);
                      for (int i3 = 0; i3 <= min(-i0 - 1, 2 * t0 - i0 - i1 + 1); i3 += 1) {
                        for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                          Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          for (int t0 = 8 * h0 + N / 2 + 8; t0 <= min(8 * w0 + 15, (N + 1) / 2 - 2); t0 += 1) {
            for (int i0 = max(-N + 3, -N + 2 * t0 - 13); i0 <= 16 * h0 + 15; i0 += 1) {
              for (int i1 = max(max(16 * w0 - 16 * h0, 2 * t0 - i0 - 15), -i0 + 1); i1 < N - 1; i1 += 1) {
                for (int i3 = 2 * t0 - i0 - i1; i3 <= min(15, 2 * t0 - i0 - i1 + 1); i3 += 1) {
                  for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                    Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                  }
                }
              }
            }
          }
          for (int t0 = 8 * w0 + 16; t0 <= min(min(8 * w0 + 22, 8 * w0 - 8 * h0 + 7), 8 * h0 + N / 2 + 14); t0 += 1) {
            for (int i0 = max(-16 * w0 + 16 * h0 + 2 * t0 - 30, -N + 2 * t0 - 13); i0 <= 16 * h0 + 15; i0 += 1) {
              for (int i1 = 2 * t0 - i0 - 15; i1 <= min(N - 2, 16 * w0 - 16 * h0 + 15); i1 += 1) {
                for (int i3 = 2 * t0 - i0 - i1; i3 <= min(15, 2 * t0 - i0 - i1 + 1); i3 += 1) {
                  for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                    Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
 */

//Tiles 3D 16x16x16 with sequential tiles 4x4x4:
 /*
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 sizetimetile=1 sizetime1=4 sizetime2=4 sizetime3=4 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))

if (N >= 2) {
  for (int w0 = max(-1, -((N + 13) / 16)); w0 <= (N - 1) / 16; w0 += 1) {
    {
      #pragma omp parallel for
      for (int h0 = -((N + 12) / 16); h0 <= w0 - (N + 15) / 16; h0 += 1) {
        for (int h1 = max(w0 + 1, -h0 - 1); h1 <= (N - 2) / 16; h1 += 1) {
          for (int t0 = max(4 * w0, 4 * w0 - 4 * h0 - 4 * h1 - 1); t0 <= min(min(min(4 * w0 + 9, 4 * h1 + 2), (N + 2) / 4 - 2), 4 * w0 - 4 * h1 + (N + 2) / 4 + 5); t0 += 1) {
            for (int i0 = max(max(max(max(-N + 3, 16 * h0), -16 * h1 - 14), -16 * w0 + 16 * h0 + 4 * t0 - 24), -N - 16 * w0 + 16 * h0 + 16 * h1 + 4 * t0 - 10); i0 <= min(16 * h0 + 15, -16 * w0 + 16 * h0 + 4 * t0 + 3); i0 += 1) {
              for (int i1 = max(max(max(16 * h1, 4 * t0 + 4), -16 * w0 + 16 * h0 + 16 * h1 + 4 * t0 - i0 - 12), -i0 + 1); i1 <= min(min(N - 2, 16 * h1 + 15), -16 * w0 + 16 * h0 + 16 * h1 + 4 * t0 - i0 + 6); i1 += 1) {
                if ((i1 % 4) + 16 * h0 + 16 * h1 + 4 * t0 + 3 >= 16 * w0 + i0 + i1 && 16 * w0 + i0 + i1 + 12 >= (i1 % 4) + 16 * h0 + 16 * h1 + 4 * t0) {
                  for (int i3 = (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 3; i3 <= min(-i0 - 1, (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 6); i3 += 1) {
                    for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                      Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                    }
                  }
                }
              }
            }
          }
        }
      }
      #pragma omp parallel for
      for (int h0 = max(w0 - (N + 15) / 16 + 1, -((N + 13) / 16)); h0 <= min(0, w0); h0 += 1) {
        {
          for (int h1 = max(w0 + 1, -h0 - 1); h1 < w0 - h0; h1 += 1) {
            for (int t0 = max(4 * w0, 4 * w0 - 4 * h0 - 4 * h1 - 1); t0 <= min(4 * w0 + 9, 4 * h1 + 2); t0 += 1) {
              for (int i0 = max(max(16 * h0, -16 * h1 - 14), -16 * w0 + 16 * h0 + 4 * t0 - 24); i0 <= min(16 * h0 + 15, -16 * w0 + 16 * h0 + 4 * t0 + 3); i0 += 1) {
                for (int i1 = max(max(max(16 * h1, 4 * t0 + 4), -16 * w0 + 16 * h0 + 16 * h1 + 4 * t0 - i0 - 12), -i0 + 1); i1 <= min(16 * h1 + 15, -16 * w0 + 16 * h0 + 16 * h1 + 4 * t0 - i0 + 6); i1 += 1) {
                  if ((i1 % 4) + 16 * h0 + 16 * h1 + 4 * t0 + 3 >= 16 * w0 + i0 + i1 && 16 * w0 + i0 + i1 + 12 >= (i1 % 4) + 16 * h0 + 16 * h1 + 4 * t0) {
                    for (int i3 = (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 3; i3 <= min(-i0 - 1, (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 6); i3 += 1) {
                      for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                        Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                      }
                    }
                  }
                }
              }
            }
          }
          for (int t0 = max(-1, 4 * w0); t0 <= min(min(min(4 * w0 + 6, 4 * w0 - 4 * h0 + 3), (N - 1) / 4), 4 * h0 + (N - 1) / 4 + 3); t0 += 1) {
            {
              for (int i0 = max(max(max(-N + 3, -16 * w0 + 16 * h0 - 14), 16 * h0), -N + 4 * t0 - 10); i0 <= -N + 4 * t0; i0 += 1) {
                for (int i1 = max(max(max(16 * w0 - 16 * h0, 4 * t0 + 4), 4 * t0 - i0 - 12), -i0 + 1); i1 <= min(N - 2, 16 * w0 - 16 * h0 + 15); i1 += 1) {
                  if (i0 + i1 + 12 >= (i1 % 4) + 4 * t0) {
                    for (int i3 = (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 3; i3 <= min(-i0 - 1, (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 6); i3 += 1) {
                      for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                        Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                      }
                    }
                  }
                }
              }
              for (int i0 = max(max(max(-N + 3, -16 * w0 + 16 * h0 - 14), 16 * h0), -N + 4 * t0 + 1); i0 < -16 * w0 + 16 * h0 + 4 * t0 - 12; i0 += 1) {
                for (int i1 = max(max(4 * t0 + 4, 4 * t0 - i0 - 12), -i0 + 1); i1 <= min(N - 2, 16 * w0 - 16 * h0 + 15); i1 += 1) {
                  if (i0 + i1 + 12 >= (i1 % 4) + 4 * t0) {
                    for (int i3 = (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 3; i3 <= min(-i0 - 1, (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 6); i3 += 1) {
                      for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                        Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                      }
                    }
                  }
                }
              }
              for (int i0 = max(max(max(max(-N + 2, 16 * h0), -16 * w0 + 16 * h0 + 4 * t0 - 12), 16 * h0 - 4 * t0 - 2), -N + 4 * t0 + 1); i0 <= min(min(0, 16 * h0 + 15), -16 * w0 + 16 * h0 + 4 * t0 + 3); i0 += 1) {
                {
                  for (int i1 = max(max(16 * w0 - 16 * h0, 4 * t0 + 4), -i0 + 1); i1 <= min(N - 2, -((-i0 + 3) % 4) + 4 * t0 - i0 + 2); i1 += 1) {
                    for (int i3 = (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 3; i3 <= min(-i0 - 1, (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 6); i3 += 1) {
                      for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                        Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                      }
                    }
                  }
                  for (int i1 = max(-i0 + 1, -((-i0 + 3) % 4) + 4 * t0 - i0 + 3); i1 <= min(N - 1, -((-i0 + 3) % 4) + 4 * t0 - i0 + 6); i1 += 1) {
                    {
                      Pu[-i0][i1] = (((Q[0][-i0] * Q[i1][N - 1]) * 1) / Q[0][N - 1]);
                      for (int i3 = 0; i3 <= min(3, -i0 - 1); i3 += 1) {
                        for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                          Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          for (int t0 = 4 * w0 + 7; t0 <= min(min(4 * w0 + 9, 4 * w0 - 4 * h0 + 2), 4 * h0 + (N - 1) / 4 + 3); t0 += 1) {
            for (int i0 = -16 * w0 + 16 * h0 + 4 * t0 - 24; i0 <= 16 * h0 + 15; i0 += 1) {
              for (int i1 = max(4 * t0 - i0 - 12, -i0 + 1); i1 <= 16 * w0 - 16 * h0 + 15; i1 += 1) {
                if (i0 + i1 + 12 >= (i1 % 4) + 4 * t0) {
                  for (int i3 = (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 3; i3 <= (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 6; i3 += 1) {
                    for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                      Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                    }
                  }
                }
              }
            }
          }
          for (int t0 = 4 * h0 + (N - 1) / 4 + 4; t0 <= min(min(4 * w0 + 9, (N + 2) / 4 - 2), 4 * h0 + (N + 2) / 4 + 5); t0 += 1) {
            for (int i0 = max(max(-N + 3, -16 * w0 + 16 * h0 + 4 * t0 - 24), -N + 4 * t0 - 10); i0 <= 16 * h0 + 15; i0 += 1) {
              for (int i1 = max(max(16 * w0 - 16 * h0, 4 * t0 - i0 - 12), -i0 + 1); i1 <= min(N - 2, 16 * w0 - 16 * h0 + 15); i1 += 1) {
                if (i0 + i1 + 12 >= (i1 % 4) + 4 * t0) {
                  for (int i3 = (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 3; i3 <= (i1 % 4) - ((-i0 + 3) % 4) + 4 * t0 - i0 - i1 + 6; i3 += 1) {
                    for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                      Pu[-i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][-i0]) * 1) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
*/

