int paired(int, int);
int MAX(int, int);

void foo2(int N, int l, int **M, int *Puu, int **Pbp, int delta){
#pragma scop
	for(int i=N-1; i>=0; i--){
		for(int j=i+1; j<N; j++){
			for(int k=0; k<j-i-l; k++){
	        M[i][j] = MAX(M[i][j], M[i][k+i-1] + M[k+i+1][j-1] + delta*Pbp[k+i][j])*paired(k+i,j-1);
	      }
	      M[i][j] = MAX(M[i][j], M[i][j-1] + Puu[j-1]);
	     }
	    }
#pragma endscop
}



//Tiles 3D 16x16x16:
/*
//dapt filename=./work_test.c size=16 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = max(floord(-l + 1, 16) - 1, floord(-N - l + 4, 16) - 1); w0 <= floord(2 * N - l - 2, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(-((N + 13) / 16), -((2 * N - l - 16 * w0 + 45) / 32) + 1); h0 <= min(0, w0 + floord(l - 2, 16) + 1); h0 += 1) {
    for (int h1 = max(max(max(w0 - h0 + floord(-N + l, 16) + 1, w0 - 2 * h0 + floord(-N + l + 1, 16)), -h0 + floord(l + 16 * w0 + 1, 32)), -h0 + floord(l + 16 * w0 + 16 * h0 + 16, 32)); h1 <= min(min(floord(N - 1, 16), w0 - h0 + floord(l - 2, 16) + 1), -h0 + floord(l + 16 * w0 + 15, 32)); h1 += 1) {
      for (int i0 = max(max(max(max(-N + 2, 16 * h0), l + 16 * w0 - 16 * h0 - 32 * h1 - 15), -16 * h1 - 14), -N + l + 16 * w0 - 16 * h0 - 16 * h1 + 1); i0 <= min(min(0, 16 * h0 + 15), l + 16 * w0 - 16 * h0 - 32 * h1 + 15); i0 += 1) {
        for (int i1 = max(max(16 * h1, l + 16 * w0 - 16 * h0 - 16 * h1 - i0), -i0 + 1); i1 <= min(min(N - 1, 16 * h1 + 15), l + 16 * w0 - 16 * h0 - 16 * h1 - i0 + 15); i1 += 1) {
          M[-i0][i1] = MAX(M[-i0][i1], M[-i0][i1 - 1] + Puu[i1 - 1]);
        }
      }
    }
  }
}
*/

//Tiles 3D 16x16x16 with timeline=2:
/*
//dapt filename=./work_test.c size=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 sizetimetile=2 sizetime1=1 sizetime2=1 sizetime3=1 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = max(floord(-l + 1, 16) - 1, floord(-N - l + 4, 16) - 1); w0 <= floord(2 * N - l - 2, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(-((N + 13) / 16), -((2 * N - l - 16 * w0 + 45) / 32) + 1); h0 <= min(0, w0 + floord(l - 2, 16) + 1); h0 += 1) {
    for (int h1 = max(max(max(w0 - h0 + floord(-N + l, 16) + 1, w0 - 2 * h0 + floord(-N + l + 1, 16)), -h0 + floord(l + 16 * w0 + 1, 32)), -h0 + floord(l + 16 * w0 + 16 * h0 + 16, 32)); h1 <= min(min(floord(N - 1, 16), w0 - h0 + floord(l - 2, 16) + 1), -h0 + floord(l + 16 * w0 + 15, 32)); h1 += 1) {
      for (int t0 = max(max(-l + 16 * h0 + 16 * h1 + floord(l, 2), 16 * w0 - 16 * h0 - 16 * h1 + floord(l, 2)), -l + floord(l, 2) + 1); t0 <= min(min(min(min(N - l + floord(l, 2) - 1, N - l + 16 * h0 + floord(l, 2) + 14), -l + 16 * h1 + floord(l, 2) + 15), 16 * w0 - 16 * h0 - 16 * h1 + floord(l, 2) + 15), -l + 16 * h0 + 16 * h1 + floord(l, 2) + 30); t0 += 1) {
        for (int i0 = max(max(16 * h0, -16 * h1 + t0 + (l + 1) / 2 - 15), -N + t0 + (l + 1) / 2 + 1); i0 <= min(min(0, 16 * h0 + 15), -16 * h1 + t0 + (l + 1) / 2); i0 += 1) {
          M[-i0][t0 - i0 + (l + 1) / 2] = MAX(M[-i0][t0 - i0 + (l + 1) / 2], M[-i0][t0 - i0 + (l + 1) / 2 - 1] + Puu[t0 - i0 + (l + 1) / 2 - 1]);
        }
      }
    }
  }
}
 */

//Tiles 3D 16x16x16 with sequential tiles 4x4x4:
 /*
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 sizetimetile=1 sizetime1=4 sizetime2=4 sizetime3=4 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

for (int w0 = max(floord(-l + 1, 16) - 1, floord(-N - l + 4, 16) - 1); w0 <= floord(2 * N - l - 2, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(-((N + 13) / 16), -((2 * N - l - 16 * w0 + 45) / 32) + 1); h0 <= min(0, w0 + floord(l - 2, 16) + 1); h0 += 1) {
    for (int h1 = max(max(max(w0 - h0 + floord(-N + l, 16) + 1, w0 - 2 * h0 + floord(-N + l + 1, 16)), -h0 + floord(l + 16 * w0 + 1, 32)), -h0 + floord(l + 16 * w0 + 16 * h0 + 16, 32)); h1 <= min(min(floord(N - 1, 16), w0 - h0 + floord(l - 2, 16) + 1), -h0 + floord(l + 16 * w0 + 15, 32)); h1 += 1) {
      for (int t0 = max(max(max(max(max(max(4 * w0, 8 * h0 + 8 * h1 + floord(-l, 4)), 8 * w0 - 4 * h0 - 8 * h1 + floord(l, 4)), 8 * w0 - 8 * h0 - 4 * h1 + floord(-N + l + 1, 4)), floord(-l + 1, 4) - 1), 4 * h0 + 4 * h1 + floord(-l + 1, 4)), 8 * w0 - 8 * h0 - 8 * h1 + floord(l + 1, 4) - 1); t0 <= min(min(min(min(min(min(min(min(min(4 * w0 + 9, 4 * w0 - 4 * h0 - 4 * h1 + (N - 1) / 4 + 3), 4 * w0 - 4 * h1 + (N - 1) / 4 + 6), 8 * h1 + floord(-l - 1, 4) + 7), 8 * w0 - 8 * h0 - 8 * h1 + floord(l - 1, 4) + 7), 4 * h1 + floord(N - l - 1, 4) + 3), 8 * h0 + floord(2 * N - l + 1, 4) + 6), 8 * h0 + 8 * h1 + floord(-l + 2, 4) + 13), 8 * h0 + 4 * h1 + floord(N - l + 2, 4) + 9), floord(2 * N - l + 2, 4) - 1); t0 += 1) {
        for (int i0 = max(max(max(max(max(max(max(max(max(max(max(max(max(-N + 2, 16 * h0), -N + l + 16 * w0 - 16 * h0 - 16 * h1 + 1), -16 * w0 + 16 * h0 + 4 * t0 - 24), -N - 16 * w0 + 16 * h0 + 16 * h1 + 4 * t0 - 11), -2 * N + l - 16 * h0 + 4 * t0 - 10), -l + 16 * h0 - 4 * t0 - 4), l + 32 * w0 - 16 * h0 - 32 * h1 - 4 * t0 - 3), 16 * w0 - 16 * h1 - 4 * t0 - 2), -N - 8 * h1 + 2 * t0 + floord(N + l, 2) - 5), -16 * h1 + 2 * t0 + floord(l + 1, 2) - 15), -N + 2 * t0 + floord(l + 1, 2) + 1), -5 * w0 + 5 * h0 - 11 * h1 + 3 * t0 + floord(l - w0 + h0 + h1 - t0 - 1, 3) - 16), 5 * h0 - 11 * h1 + t0 + floord(l + h0 + h1 + t0 - 1, 3) - 8); i0 <= min(min(min(min(min(min(0, 16 * h0 + 15), -16 * w0 + 16 * h0 + 4 * t0 + 3), l + 32 * w0 - 16 * h0 - 32 * h1 - 4 * t0 + 39), -16 * h1 + 2 * t0 + floord(l + 1, 2) + 4), -5 * w0 + 5 * h0 - 11 * h1 + 3 * t0 + floord(l - w0 + h0 + h1 - t0, 3) + 3), 5 * h0 - 11 * h1 + t0 + floord(l + h0 + h1 + t0, 3) + 7); i0 += 1) {
          for (int i1 = max(max(max(max(16 * h1, l + 16 * w0 - 16 * h0 - 16 * h1 - i0), -i0 + 1), -((-i0 + 3) % 4) + l - 16 * h1 + 4 * t0 - 2 * i0 - 9), 2 * t0 - i0 + (l + i0 + 1) / 2 + 2 * ((-i0 + 3) / 4)); i1 <= min(min(min(min(N - 1, 16 * h1 + 15), l + 16 * w0 - 16 * h0 - 16 * h1 - i0 + 15), -((-i0 + 3) % 4) + l - 16 * h1 + 4 * t0 - 2 * i0 + 6), 2 * t0 - i0 + (l + i0) / 2 + 2 * ((-i0 + 3) / 4) + 3); i1 += 1) {
            if (((-i0 + 3) % 4) + 2 * i0 + 2 * i1 >= (i1 % 4) + l + 4 * t0 + 3 && (i1 % 4) + l + 4 * t0 + 6 >= ((-i0 + 3) % 4) + 2 * i0 + 2 * i1) {
              M[-i0][i1] = MAX(M[-i0][i1], M[-i0][i1 - 1] + Puu[i1 - 1]);
            }
          }
        }
      }
    }
  }
}
*/

