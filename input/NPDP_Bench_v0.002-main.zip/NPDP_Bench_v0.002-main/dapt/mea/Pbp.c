
void foo2(int N, int l, int **Q, int **Qbp, int **Pbp, int ERT){
#pragma scop
	for(int i=0; i<N; i++){
		for(int j=i+1; j<N; j++){
	       Pbp[i][j] = (Q[0][i]*Q[j][N-1]*Qbp[i][j])/Q[0][N-1];
	       for(int p=0; p<i; p++){
	    	   for(int q=j+1; q<N; q++){
	    		   Pbp[i][j] += (Pbp[p][q] * ERT * Q[p+1][i] * Qbp[i][j] * Q[j+1][q-1]) / (Qbp[p][q] ==0 ? 1 : Qbp[p][q]) ;
	    	   }
	       }
		}
	}
#pragma endscop
}

//Tiles 3D 16x16x16:
/*
//dapt filename=./work_test.c size=16 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

{
  for (int w0 = floord(-N + 1, 16); w0 < 0; w0 += 1) {
    #pragma omp parallel for
    for (int h0 = 0; h0 <= w0 + (N - 2) / 16 + 1; h0 += 1) {
      {
        for (int h1 = max(w0 - 2 * h0, -((N + 13) / 16)); h1 < w0 - h0; h1 += 1) {
          for (int i0 = max(16 * h0, 16 * w0 - 16 * h0 - 16 * h1 + 1); i0 <= 16 * h0 + 15; i0 += 1) {
            for (int i1 = -16 * h1 - 15; i1 <= min(N - 2, -16 * h1); i1 += 1) {
              for (int i3 = 16 * w0 - 16 * h0 - 16 * h1; i3 <= min(16 * w0 - 16 * h0 - 16 * h1 + 15, i0 - 1); i3 += 1) {
                for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                  Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                }
              }
            }
          }
        }
        for (int i0 = 16 * h0; i0 <= min(N - 2, 16 * h0 + 15); i0 += 1) {
          for (int i1 = max(-16 * w0 + 16 * h0 - 15, i0 + 1); i1 <= min(N - 1, -16 * w0 + 16 * h0); i1 += 1) {
            {
              Pbp[i0][i1] = (((Q[0][i0] * Q[i1][N - 1]) * Qbp[i0][i1]) / Q[0][N - 1]);
              for (int i3 = 0; i3 <= min(15, i0 - 1); i3 += 1) {
                for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                  Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                }
              }
            }
          }
        }
      }
    }
  }
  for (int w0 = 0; w0 < floord(N - 4, 16); w0 += 1) {
    #pragma omp parallel for
    for (int h0 = w0 + 1; h0 <= (N - 3) / 16; h0 += 1) {
      for (int h1 = max(w0 - 2 * h0, -((N + 13) / 16)); h1 < -h0; h1 += 1) {
        for (int i0 = max(16 * h0, 16 * w0 - 16 * h0 - 16 * h1 + 1); i0 <= min(N - 3, 16 * h0 + 15); i0 += 1) {
          for (int i1 = max(-16 * h1 - 15, i0 + 1); i1 <= min(N - 2, -16 * h1); i1 += 1) {
            for (int i3 = 16 * w0 - 16 * h0 - 16 * h1; i3 <= min(16 * w0 - 16 * h0 - 16 * h1 + 15, i0 - 1); i3 += 1) {
              for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
              }
            }
          }
        }
      }
    }
  }
}
*/

//Tiles 3D 16x16x16 with timeline=2:
/*
//dapt filename=./work_test.c size=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 sizetimetile=2 sizetime1=1 sizetime2=1 sizetime3=1 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

{
  for (int w0 = floord(-N + 1, 16); w0 < 0; w0 += 1) {
    #pragma omp parallel for
    for (int h0 = 0; h0 <= w0 + (N - 2) / 16 + 1; h0 += 1) {
      {
        for (int h1 = max(w0 - 2 * h0, -((N + 13) / 16)); h1 < w0 - h0; h1 += 1) {
          for (int t0 = max(max(8 * w0, -N + 8 * w0 - 8 * h1 + N / 2 + 1), -N + 16 * w0 - 16 * h0 - 16 * h1 + (N + 1) / 2 + 1); t0 <= 8 * w0 + 22; t0 += 1) {
            for (int i0 = max(max(max(16 * h0, 16 * w0 - 16 * h0 - 16 * h1 + 1), -16 * w0 + 16 * h0 + 2 * t0 - 30), -8 * h1 + t0 - 7); i0 <= min(min(16 * h0 + 15, N - 16 * w0 + 16 * h0 + 16 * h1 + 2 * t0 - 1), -16 * w0 + 16 * h0 + 2 * t0 + 1); i0 += 1) {
              for (int i1 = max(-16 * h1 - 15, 16 * w0 - 16 * h0 - 16 * h1 - 2 * t0 + i0 - 1); i1 <= min(min(min(N - 2, -16 * h1), -2 * t0 + 2 * i0 - 1), 16 * w0 - 16 * h0 - 16 * h1 - 2 * t0 + i0 + 15); i1 += 1) {
                for (int i3 = max(16 * w0 - 16 * h0 - 16 * h1, 2 * t0 - i0 + i1); i3 <= min(min(16 * w0 - 16 * h0 - 16 * h1 + 15, i0 - 1), 2 * t0 - i0 + i1 + 1); i3 += 1) {
                  for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                    Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                  }
                }
              }
            }
          }
        }
        for (int t0 = max(8 * w0, -N + 8 * h0 + (N + 1) / 2); t0 <= min(-1, 8 * w0 + 15); t0 += 1) {
          {
            for (int i0 = max(16 * h0, -8 * w0 + 8 * h0 + t0 - 7); i0 < -16 * w0 + 16 * h0 + 2 * t0 - 15; i0 += 1) {
              for (int i1 = -16 * w0 + 16 * h0 - 15; i1 <= min(min(N - 2, -2 * t0 + 2 * i0 - 1), -2 * t0 + i0 + 15); i1 += 1) {
                for (int i3 = 2 * t0 - i0 + i1; i3 <= min(min(15, i0 - 1), 2 * t0 - i0 + i1 + 1); i3 += 1) {
                  for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                    Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                  }
                }
              }
            }
            for (int i0 = max(16 * h0, -16 * w0 + 16 * h0 + 2 * t0 - 15); i0 <= min(min(16 * h0 + 15, N + 2 * t0), -16 * w0 + 16 * h0 + 2 * t0 + 1); i0 += 1) {
              {
                for (int i1 = max(-16 * w0 + 16 * h0 - 15, -2 * t0 + i0 - 1); i1 <= min(min(N - 1, -16 * w0 + 16 * h0), -2 * t0 + i0); i1 += 1) {
                  {
                    Pbp[i0][i1] = (((Q[0][i0] * Q[i1][N - 1]) * Qbp[i0][i1]) / Q[0][N - 1]);
                    for (int i3 = 0; i3 <= min(i0 - 1, 2 * t0 - i0 + i1 + 1); i3 += 1) {
                      for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                        Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                      }
                    }
                  }
                }
                for (int i1 = -2 * t0 + i0 + 1; i1 <= min(min(N - 2, -16 * w0 + 16 * h0), -2 * t0 + 2 * i0 - 1); i1 += 1) {
                  for (int i3 = 2 * t0 - i0 + i1; i3 <= min(min(15, i0 - 1), 2 * t0 - i0 + i1 + 1); i3 += 1) {
                    for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                      Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                    }
                  }
                }
              }
            }
          }
        }
        for (int t0 = 8 * w0 + 16; t0 <= min(-1, 8 * w0 + 22); t0 += 1) {
          for (int i0 = max(-16 * w0 + 16 * h0 + 2 * t0 - 30, -8 * w0 + 8 * h0 + t0 - 7); i0 <= 16 * h0 + 15; i0 += 1) {
            for (int i1 = -16 * w0 + 16 * h0 - 15; i1 <= min(min(N - 2, -2 * t0 + 2 * i0 - 1), -2 * t0 + i0 + 15); i1 += 1) {
              for (int i3 = 2 * t0 - i0 + i1; i3 <= min(min(15, i0 - 1), 2 * t0 - i0 + i1 + 1); i3 += 1) {
                for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                  Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                }
              }
            }
          }
        }
        for (int t0 = 0; t0 <= min(min(min(7, 8 * w0 + 22), 8 * h0 + 6), (N + 1) / 2 - 3); t0 += 1) {
          for (int i0 = max(max(max(16 * h0, -16 * w0 + 16 * h0 + 2 * t0 - 30), -8 * w0 + 8 * h0 + t0 - 7), 2 * t0 + 2); i0 <= min(N - 3, 16 * h0 + 15); i0 += 1) {
            for (int i1 = max(-16 * w0 + 16 * h0 - 15, i0 + 1); i1 <= min(min(min(N - 2, -16 * w0 + 16 * h0), -2 * t0 + 2 * i0 - 1), -2 * t0 + i0 + 15); i1 += 1) {
              for (int i3 = 2 * t0 - i0 + i1; i3 <= min(min(15, i0 - 1), 2 * t0 - i0 + i1 + 1); i3 += 1) {
                for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                  Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                }
              }
            }
          }
        }
      }
    }
  }
  for (int w0 = 0; w0 < floord(N - 4, 16); w0 += 1) {
    #pragma omp parallel for
    for (int h0 = w0 + 1; h0 <= (N - 3) / 16; h0 += 1) {
      for (int h1 = max(w0 - 2 * h0, -((N + 13) / 16)); h1 < -h0; h1 += 1) {
        for (int t0 = max(max(8 * w0, -N + 8 * w0 - 8 * h1 + N / 2 + 1), -N + 16 * w0 - 16 * h0 - 16 * h1 + (N + 1) / 2 + 1); t0 <= min(min(min(8 * w0 + 22, 8 * h0 + 6), 8 * w0 - 8 * h0 - 8 * h1 + 7), (N + 1) / 2 - 3); t0 += 1) {
          for (int i0 = max(max(max(max(16 * h0, 16 * w0 - 16 * h0 - 16 * h1 + 1), -16 * w0 + 16 * h0 + 2 * t0 - 30), -8 * h1 + t0 - 7), 2 * t0 + 2); i0 <= min(min(min(N - 3, 16 * h0 + 15), N - 16 * w0 + 16 * h0 + 16 * h1 + 2 * t0 - 1), -16 * w0 + 16 * h0 + 2 * t0 + 1); i0 += 1) {
            for (int i1 = max(max(-16 * h1 - 15, 16 * w0 - 16 * h0 - 16 * h1 - 2 * t0 + i0 - 1), i0 + 1); i1 <= min(min(min(N - 2, -16 * h1), -2 * t0 + 2 * i0 - 1), 16 * w0 - 16 * h0 - 16 * h1 - 2 * t0 + i0 + 15); i1 += 1) {
              for (int i3 = max(16 * w0 - 16 * h0 - 16 * h1, 2 * t0 - i0 + i1); i3 <= min(min(16 * w0 - 16 * h0 - 16 * h1 + 15, i0 - 1), 2 * t0 - i0 + i1 + 1); i3 += 1) {
                for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                  Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                }
              }
            }
          }
        }
      }
    }
  }
}
 */

//Tiles 3D 16x16x16 with sequential tiles 4x4x4:
 /*
//dapt filename=./work_test.c sizes=3 size1=16 size2=16 size3=16 sizetimetile=1 sizetime1=4 sizetime2=4 sizetime3=4 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

{
  for (int w0 = floord(-N + 1, 16); w0 < 0; w0 += 1) {
    #pragma omp parallel for
    for (int h0 = 0; h0 <= w0 + (N - 2) / 16 + 1; h0 += 1) {
      {
        for (int h1 = max(w0 - 2 * h0, -((N + 13) / 16)); h1 < w0 - h0; h1 += 1) {
          for (int t0 = max(4 * w0, 4 * w0 - 4 * h1 - (N + 1) / 4); t0 <= 4 * w0 + 9; t0 += 1) {
            for (int i0 = max(max(16 * h0, -16 * w0 + 16 * h0 + 4 * t0 - 24), -8 * h1 + 2 * t0 - 5); i0 <= min(min(16 * h0 + 15, -16 * w0 + 16 * h0 + 4 * t0 + 3), N - 16 * w0 + 16 * h0 + 16 * h1 + 4 * t0 + 4); i0 += 1) {
              if (16 * h1 + 2 * i0 + 11 >= (i0 % 4) + 4 * t0) {
                for (int i1 = max(-16 * h1 - 15, 16 * w0 - 16 * h0 - 16 * h1 - 4 * t0 + i0 - 6); i1 <= min(min(min(N - 2, -16 * h1), 16 * w0 - 16 * h0 - 16 * h1 - 4 * t0 + i0 + 12), -(i0 % 4) - 4 * t0 + 2 * i0 - 1); i1 += 1) {
                  if (16 * h0 + 16 * h1 + 4 * t0 + i1 + 6 >= ((i1 + 3) % 4) + 16 * w0 + i0 && ((i1 + 3) % 4) + 16 * w0 + i0 + 9 >= 16 * h0 + 16 * h1 + 4 * t0 + i1) {
                    for (int i3 = (i0 % 4) - ((i1 + 3) % 4) + 4 * t0 - i0 + i1 + 3; i3 <= min(i0 - 1, (i0 % 4) - ((i1 + 3) % 4) + 4 * t0 - i0 + i1 + 6); i3 += 1) {
                      for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                        Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                      }
                    }
                  }
                }
              }
            }
          }
        }
        for (int t0 = max(4 * w0, 4 * h0 - (N + 2) / 4); t0 <= min(-1, 4 * w0 + 6); t0 += 1) {
          {
            for (int i0 = max(max(5, 16 * h0), -8 * w0 + 8 * h0 + 2 * t0 - 5); i0 < -16 * w0 + 16 * h0 + 4 * t0 - 12; i0 += 1) {
              if (16 * w0 + 2 * i0 + 11 >= (i0 % 4) + 16 * h0 + 4 * t0) {
                for (int i1 = -16 * w0 + 16 * h0 - 15; i1 <= min(min(N - 2, -4 * t0 + i0 + 12), -(i0 % 4) - 4 * t0 + 2 * i0 - 1); i1 += 1) {
                  if (((i1 + 3) % 4) + i0 + 9 >= 4 * t0 + i1) {
                    for (int i3 = (i0 % 4) - ((i1 + 3) % 4) + 4 * t0 - i0 + i1 + 3; i3 <= min(i0 - 1, (i0 % 4) - ((i1 + 3) % 4) + 4 * t0 - i0 + i1 + 6); i3 += 1) {
                      for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                        Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                      }
                    }
                  }
                }
              }
            }
            for (int i0 = max(16 * h0, -16 * w0 + 16 * h0 + 4 * t0 - 12); i0 <= min(min(min(N - 2, 16 * h0 + 15), -16 * w0 + 16 * h0 + 4 * t0 + 3), N + 4 * t0 + 5); i0 += 1) {
              {
                for (int i1 = max(i0 + 1, -((i0 + 4) % 4) - 4 * t0 + i0 - 3); i1 < min(N, -((i0 + 4) % 4) - 4 * t0 + i0 + 1); i1 += 1) {
                  {
                    Pbp[i0][i1] = (((Q[0][i0] * Q[i1][N - 1]) * Qbp[i0][i1]) / Q[0][N - 1]);
                    for (int i3 = 0; i3 <= min(3, i0 - 1); i3 += 1) {
                      for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                        Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                      }
                    }
                  }
                }
                if (i0 >= 5) {
                  for (int i1 = -(i0 % 4) - 4 * t0 + i0 + 1; i1 <= min(min(N - 2, -16 * w0 + 16 * h0), -(i0 % 4) - 4 * t0 + 2 * i0 - 1); i1 += 1) {
                    for (int i3 = (i0 % 4) - ((i1 + 3) % 4) + 4 * t0 - i0 + i1 + 3; i3 <= min(i0 - 1, (i0 % 4) - ((i1 + 3) % 4) + 4 * t0 - i0 + i1 + 6); i3 += 1) {
                      for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                        Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                      }
                    }
                  }
                }
              }
            }
          }
        }
        for (int t0 = 4 * w0 + 7; t0 <= min(-1, 4 * w0 + 9); t0 += 1) {
          for (int i0 = max(-16 * w0 + 16 * h0 + 4 * t0 - 24, -8 * w0 + 8 * h0 + 2 * t0 - 5); i0 <= 16 * h0 + 15; i0 += 1) {
            if (16 * w0 + 2 * i0 + 11 >= (i0 % 4) + 16 * h0 + 4 * t0) {
              for (int i1 = -16 * w0 + 16 * h0 - 15; i1 <= min(min(N - 2, -4 * t0 + i0 + 12), -(i0 % 4) - 4 * t0 + 2 * i0 - 1); i1 += 1) {
                if (((i1 + 3) % 4) + i0 + 9 >= 4 * t0 + i1) {
                  for (int i3 = (i0 % 4) - ((i1 + 3) % 4) + 4 * t0 - i0 + i1 + 3; i3 <= min(i0 - 1, (i0 % 4) - ((i1 + 3) % 4) + 4 * t0 - i0 + i1 + 6); i3 += 1) {
                    for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                      Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                    }
                  }
                }
              }
            }
          }
        }
        for (int t0 = 0; t0 <= min(min(2, 4 * w0 + 9), N / 4 - 2); t0 += 1) {
          for (int i0 = max(max(max(16 * h0, -16 * w0 + 16 * h0 + 4 * t0 - 24), -8 * w0 + 8 * h0 + 2 * t0 - 5), 4 * t0 + 4); i0 <= min(N - 3, 16 * h0 + 15); i0 += 1) {
            if (16 * w0 + 2 * i0 + 11 >= (i0 % 4) + 16 * h0 + 4 * t0) {
              for (int i1 = max(-16 * w0 + 16 * h0 - 15, i0 + 1); i1 <= min(min(min(N - 2, -16 * w0 + 16 * h0), -4 * t0 + i0 + 12), -(i0 % 4) - 4 * t0 + 2 * i0 - 1); i1 += 1) {
                if (((i1 + 3) % 4) + i0 + 9 >= 4 * t0 + i1) {
                  for (int i3 = (i0 % 4) - ((i1 + 3) % 4) + 4 * t0 - i0 + i1 + 3; i3 <= min(i0 - 1, (i0 % 4) - ((i1 + 3) % 4) + 4 * t0 - i0 + i1 + 6); i3 += 1) {
                    for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                      Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  for (int w0 = 0; w0 < floord(N - 4, 16); w0 += 1) {
    #pragma omp parallel for
    for (int h0 = w0 + 1; h0 <= (N - 3) / 16; h0 += 1) {
      for (int h1 = max(w0 - 2 * h0, -((N + 13) / 16)); h1 < -h0; h1 += 1) {
        for (int t0 = max(4 * w0, 4 * w0 - 4 * h1 - (N + 1) / 4); t0 <= min(min(4 * w0 + 9, 4 * w0 - 4 * h0 - 4 * h1 + 2), N / 4 - 2); t0 += 1) {
          for (int i0 = max(max(max(16 * h0, -16 * w0 + 16 * h0 + 4 * t0 - 24), -8 * h1 + 2 * t0 - 5), 4 * t0 + 4); i0 <= min(min(min(N - 3, 16 * h0 + 15), -16 * w0 + 16 * h0 + 4 * t0 + 3), N - 16 * w0 + 16 * h0 + 16 * h1 + 4 * t0 + 4); i0 += 1) {
            if (16 * h1 + 2 * i0 + 11 >= (i0 % 4) + 4 * t0) {
              for (int i1 = max(max(-16 * h1 - 15, 16 * w0 - 16 * h0 - 16 * h1 - 4 * t0 + i0 - 6), i0 + 1); i1 <= min(min(min(N - 2, -16 * h1), 16 * w0 - 16 * h0 - 16 * h1 - 4 * t0 + i0 + 12), -(i0 % 4) - 4 * t0 + 2 * i0 - 1); i1 += 1) {
                if (16 * h0 + 16 * h1 + 4 * t0 + i1 + 6 >= ((i1 + 3) % 4) + 16 * w0 + i0 && ((i1 + 3) % 4) + 16 * w0 + i0 + 9 >= 16 * h0 + 16 * h1 + 4 * t0 + i1) {
                  for (int i3 = (i0 % 4) - ((i1 + 3) % 4) + 4 * t0 - i0 + i1 + 3; i3 <= min(i0 - 1, (i0 % 4) - ((i1 + 3) % 4) + 4 * t0 - i0 + i1 + 6); i3 += 1) {
                    for (int i4 = i1 + 1; i4 < N; i4 += 1) {
                      Pbp[i0][i1] += (((((Pbp[i3][i4] * (ERT)) * Q[i3 + 1][i0]) * Qbp[i0][i1]) * Q[i1 + 1][i4 - 1]) / ((Qbp[i3][i4] == 0) ? 1 : Qbp[i3][i4]));
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
*/

