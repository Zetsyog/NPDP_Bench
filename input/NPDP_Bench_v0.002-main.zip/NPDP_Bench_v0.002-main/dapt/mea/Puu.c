
void foo2(int N, int l, int *Puu, int **Pbp){
#pragma scop
	for(int i=0; i<=N; i++){
		Puu[i] = 1;
		for(int j=i+1; j<N; j++){
			Puu[i] += -1 * Pbp[i][j+1];
		}
		for(int k=0; k<i; k++){
			Puu[i] += -1 * Pbp[k][i+1];
		}
	}
#pragma endscop
}

//no Tiles
/*
//dapt filename=./work_test.c size=16 method=1 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

#pragma omp parallel for
for (int ph0 = 0; ph0 <= floord(N, 16); ph0 += 1) {
  for (int i0 = 16 * ph0; i0 <= min(N, 16 * ph0 + 15); i0 += 1) {
    {
      Puu[i0] = 1;
      for (int i2 = i0 + 1; i2 < N; i2 += 1) {
        Puu[i0] += ((-1) * Pbp[i0][i2 + 1]);
      }
      for (int i2 = 0; i2 < i0; i2 += 1) {
        Puu[i0] += ((-1) * Pbp[i2][i0 + 1]);
      }
    }
  }
}
*/
