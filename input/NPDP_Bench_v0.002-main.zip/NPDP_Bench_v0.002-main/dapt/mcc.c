int paired(int, int);

void foo2(int N, int l, int **Q1, int **Qbp1, int ERT){
#pragma scop
	if(N>=1 && l>=0 && l<=5)
		for(int i=N-1; i>=0; i--){
			for(int j=i+1; j<N; j++){
				//printf("%.f\n", Q1[i][j]);
				Q1[i][j] =  Q1[i][j-1];
				for(int k=0; k<j-i-l; k++){
					Qbp1[k+i][j] = Q1[k+i+1][j-1] * ERT * paired(k+i,j-1);
					Q1[i][j] +=  Q1[i][k+i] * Qbp1[k+i][j];
					//printf("%.f\n", Q1[i][j]);
				}
			}
		}
#pragma endscop
}



//Tiles 2D 16x16:
/*
//dapt filename=./work_test.c size=16 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

if (l >= 0 && l <= 5) {
  if (l + 1 >= N) {
    for (int w0 = floord(-N + 2, 16); w0 <= 0; w0 += 1) {
      for (int i0 = max(-N + 2, 16 * w0); i0 <= min(0, 16 * w0 + 15); i0 += 1) {
        for (int i1 = -i0 + 1; i1 < N; i1 += 1) {
          Q1[-i0][i1] = Q1[-i0][i1 - 1];
        }
      }
    }
  } else {
    for (int w0 = -1; w0 <= (N - 1) / 16; w0 += 1) {
      #pragma omp parallel for
      for (int h0 = max(w0 - (N + 15) / 16 + 1, -((N + 13) / 16)); h0 <= min(0, w0); h0 += 1) {
        for (int i0 = max(max(-N + 2, -16 * w0 + 16 * h0 - 14), 16 * h0); i0 <= min(0, 16 * h0 + 15); i0 += 1) {
          for (int i1 = max(16 * w0 - 16 * h0, -i0 + 1); i1 <= min(N - 1, 16 * w0 - 16 * h0 + 15); i1 += 1) {
            {
              Q1[-i0][i1] = Q1[-i0][i1 - 1];
              for (int i3 = 0; i3 < -l + i0 + i1; i3 += 1) {
                {
                  Qbp1[-i0 + i3][i1] = ((Q1[-i0 + i3 + 1][i1 - 1] * (ERT)) * paired((-i0 + i3), (i1 - 1)));
                  Q1[-i0][i1] += (Q1[-i0][-i0 + i3] * Qbp1[-i0 + i3][i1]);
                }
              }
            }
          }
        }
      }
    }
  }
}
*/

//Tiles 2D 16x16 with timeline=2:
/*
//dapt filename=./work_test.c size=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 method=2 --debug-print-on
//or
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=2 sizetime1=1 sizetime2=1 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

if (l >= 0 && l <= 5) {
  if (l + 1 >= N) {
    for (int w0 = floord(-N + 2, 16); w0 <= 0; w0 += 1) {
      for (int t0 = 0; t0 <= min(8 * w0 + (N + 14) / 2, floord(N + 1, 2) - 1); t0 += 1) {
        for (int i0 = max(max(-N + 2, 16 * w0), -N + 2 * t0 + 1); i0 <= min(0, 16 * w0 + 15); i0 += 1) {
          for (int i1 = max(2 * t0 - i0, -i0 + 1); i1 <= min(N - 1, 2 * t0 - i0 + 1); i1 += 1) {
            Q1[-i0][i1] = Q1[-i0][i1 - 1];
          }
        }
      }
    }
  } else {
    for (int w0 = -1; w0 <= (N - 1) / 16; w0 += 1) {
      #pragma omp parallel for
      for (int h0 = max(w0 - (N + 15) / 16 + 1, -((N + 13) / 16)); h0 <= min(0, w0); h0 += 1) {
        for (int t0 = max(0, 8 * w0); t0 <= min(min(min(8 * w0 + 15, 8 * w0 - 8 * h0 + 7), 8 * h0 + N / 2 + 7), (N + 1) / 2 - 1); t0 += 1) {
          for (int i0 = max(max(max(max(-N + 2, -16 * w0 + 16 * h0 - 14), 16 * h0), -16 * w0 + 16 * h0 + 2 * t0 - 15), -N + 2 * t0 + 1); i0 <= min(min(0, 16 * h0 + 15), -16 * w0 + 16 * h0 + 2 * t0 + 1); i0 += 1) {
            for (int i1 = max(max(16 * w0 - 16 * h0, 2 * t0 - i0), -i0 + 1); i1 <= min(min(N - 1, 16 * w0 - 16 * h0 + 15), 2 * t0 - i0 + 1); i1 += 1) {
              {
                Q1[-i0][i1] = Q1[-i0][i1 - 1];
                for (int i3 = 0; i3 < -l + i0 + i1; i3 += 1) {
                  {
                    Qbp1[-i0 + i3][i1] = ((Q1[-i0 + i3 + 1][i1 - 1] * (ERT)) * paired((-i0 + i3), (i1 - 1)));
                    Q1[-i0][i1] += (Q1[-i0][-i0 + i3] * Qbp1[-i0 + i3][i1]);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
 */

//Tiles 2D 16x16 with sequential tiles 4x4:
 /*
//dapt filename=./work_test.c sizes=2 size1=16 size2=16 sizetimetile=1 sizetime1=4 sizetime2=4 method=2 --debug-print-on

//dapt code:
#define min(x,y)    ((x) < (y) ? (x) : (y))
#define max(x,y)    ((x) > (y) ? (x) : (y))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))

if (l >= 0 && l <= 5) {
  if (l + 1 >= N) {
    for (int w0 = floord(-N + 2, 4); w0 <= 0; w0 += 1) {
      for (int t0 = w0; t0 <= w0 + floord(N - 1, 4); t0 += 1) {
        for (int i0 = max(max(-N + 2, 4 * w0), 4 * w0 - 4 * t0 - 2); i0 <= min(0, 4 * w0 + 3); i0 += 1) {
          for (int i1 = max(-4 * w0 + 4 * t0, -i0 + 1); i1 <= min(N - 1, -4 * w0 + 4 * t0 + 3); i1 += 1) {
            Q1[-i0][i1] = Q1[-i0][i1 - 1];
          }
        }
      }
    }
  } else {
    for (int w0 = -1; w0 <= (N - 1) / 16; w0 += 1) {
      #pragma omp parallel for
      for (int h0 = max(w0 - (N + 15) / 16 + 1, -((N + 13) / 16)); h0 <= min(0, w0); h0 += 1) {
        for (int t0 = max(-1, 4 * w0); t0 <= min(min(min(4 * w0 + 6, 4 * w0 - 4 * h0 + 3), (N - 1) / 4), 4 * h0 + (N - 1) / 4 + 3); t0 += 1) {
          for (int i0 = max(max(max(max(-N + 2, 16 * h0), -16 * w0 + 16 * h0 + 4 * t0 - 12), 16 * h0 - 4 * t0 - 2), -N + 4 * t0 + 1); i0 <= min(min(0, 16 * h0 + 15), -16 * w0 + 16 * h0 + 4 * t0 + 3); i0 += 1) {
            for (int i1 = max(-i0 + 1, -((-i0 + 3) % 4) + 4 * t0 - i0 + 3); i1 <= min(N - 1, -((-i0 + 3) % 4) + 4 * t0 - i0 + 6); i1 += 1) {
              {
                Q1[-i0][i1] = Q1[-i0][i1 - 1];
                for (int i3 = 0; i3 < -l + i0 + i1; i3 += 1) {
                  {
                    Qbp1[-i0 + i3][i1] = ((Q1[-i0 + i3 + 1][i1 - 1] * (ERT)) * paired((-i0 + i3), (i1 - 1)));
                    Q1[-i0][i1] += (Q1[-i0][-i0 + i3] * Qbp1[-i0 + i3][i1]);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
*/

