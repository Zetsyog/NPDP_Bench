 void sw_dapt(){

//printf("- dapt - \n\n");


for (int w0 = 0; w0 <= floord(N, 8); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(0, w0 - (N + 16) / 16 + 1); h0 <= min(w0, N / 16); h0 += 1) {
    for (int i0 = max(1, 16 * h0); i0 <= min(N, 16 * h0 + 15); i0 += 1) {
      for (int i1 = max(1, 16 * w0 - 16 * h0); i1 <= min(N, 16 * w0 - 16 * h0 + 15); i1 += 1) {
        {
          m1[i0][i1] = (INT_MIN);
          for (int i3 = 1; i3 <= i0; i3 += 1) {
            m1[i0][i1] = MAX(m1[i0][i1], H[i0 - i3][i1] + W[i3]);
          }
          m2[i0][i1] = (INT_MIN);
          for (int i3 = 1; i3 <= i1; i3 += 1) {
            m2[i0][i1] = MAX(m2[i0][i1], H[i0][i1 - i3] + W[i3]);
          }
          H[i0][i1] = MAX(0, MAX(H[i0 - 1][i1 - 1] + s(a[i0], b[i0]), MAX(m1[i0][i1], m2[i0][i1])));
        }
      }
    }
  }
}

 }