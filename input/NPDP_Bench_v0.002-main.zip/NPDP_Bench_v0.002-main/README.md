# NPDP Bench
Non-serial polyadic dynamic programming benchmarks (NPDP Bench) to test automatic source-to-source optimizing compilers and manual transformations. Programs are written in C/C++ and OpenMP is supported.
