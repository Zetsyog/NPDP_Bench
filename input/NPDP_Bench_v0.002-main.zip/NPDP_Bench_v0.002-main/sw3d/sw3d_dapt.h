void sw3d_dapt(){
	
	for (int w0 = 0; w0 <= floord(3 * N, 16); w0 += 1) {
  #pragma omp parallel for
  for (int h0 = max(0, w0 - (N + 8) / 8 + 1); h0 <= min(w0, N / 16); h0 += 1) {
    for (int h1 = max(0, w0 - h0 - (N + 16) / 16 + 1); h1 <= min(w0 - h0, N / 16); h1 += 1) {
      for (int i0 = max(1, 16 * h0); i0 <= min(N, 16 * h0 + 15); i0 += 1) {
        for (int i1 = max(1, 16 * h1); i1 <= min(N, 16 * h1 + 15); i1 += 1) {
          for (int i2 = max(1, 16 * w0 - 16 * h0 - 16 * h1); i2 <= min(N, 16 * w0 - 16 * h0 - 16 * h1 + 15); i2 += 1) {
            {
              m1[i0][i1][i2] = (INT_MIN);
              for (int i4 = 1; i4 <= i0; i4 += 1) {
                m1[i0][i1][i2] = MAX(m1[i0][i1][i2], H[i0 - i4][i1][i2] - (2 * W[i4]));
              }
              m2[i0][i1][i2] = (INT_MIN);
              for (int i4 = 1; i4 <= i1; i4 += 1) {
                m2[i0][i1][i2] = MAX(m2[i0][i1][i2], H[i0][i1 - i4][i2] - (2 * W[i4]));
              }
              m3[i0][i1][i2] = (INT_MIN);
              for (int i4 = 1; i4 <= i2; i4 += 1) {
                m3[i0][i1][i2] = MAX(m3[i0][i1][i2], H[i0][i1][i2 - i4] - (2 * W[i4]));
              }
              m4[i0][i1][i2] = (INT_MIN);
              for (int i4 = 1; i4 <= min(i0, i1); i4 += 1) {
                m4[i0][i1][i2] = MAX(m4[i0][i1][i2], (H[i0 - i4][i1 - i4][i2] - W[i4]) + s(a[i0], b[i1]));
              }
              if (i1 >= i0 + 1) {
                m5[i0][i1][i2] = (INT_MIN);
              } else {
                m5[i0][i1][i2] = (INT_MIN);
              }
              for (int i4 = 1; i4 <= min(i1, i2); i4 += 1) {
                m5[i0][i1][i2] = MAX(m5[i0][i1][i2], (H[i0][i1 - i4][i2 - i4] - W[i4]) + s(b[i1], c[i2]));
              }
              if (i2 >= i1 + 1) {
                m6[i0][i1][i2] = (INT_MIN);
              } else {
                m6[i0][i1][i2] = (INT_MIN);
              }
              for (int i4 = 1; i4 <= min(i0, i2); i4 += 1) {
                m6[i0][i1][i2] = MAX(m6[i0][i1][i2], (H[i0 - i4][i1][i2 - i4] - W[i4]) + s(a[i0], c[i2]));
              }
              if (i2 >= i0 + 1) {
                H[i0][i1][i2] = MAX(0, MAX(((H[i0 - 1][i1 - 1][i2 - 1] + s(a[i0], b[i1])) + s(a[i0], c[i2])) + s(b[i1], c[i2]), MAX(m1[i0][i1][i2], MAX(m2[i0][i1][i2], MAX(m3[i0][i1][i2], MAX(m4[i0][i1][i2], MAX(m5[i0][i1][i2], m6[i0][i1][i2])))))));
              } else {
                H[i0][i1][i2] = MAX(0, MAX(((H[i0 - 1][i1 - 1][i2 - 1] + s(a[i0], b[i1])) + s(a[i0], c[i2])) + s(b[i1], c[i2]), MAX(m1[i0][i1][i2], MAX(m2[i0][i1][i2], MAX(m3[i0][i1][i2], MAX(m4[i0][i1][i2], MAX(m5[i0][i1][i2], m6[i0][i1][i2])))))));
              }
            }
          }
        }
      }
    }
  }
}
	
	
}