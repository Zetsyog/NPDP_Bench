import inquirer
import array
import subprocess
import datetime

import os

def remove_empty_lines(text):
    lines = text.split("\n")  # Split the text into lines
    non_empty_lines = [line for line in lines if line.strip() != ""]  # Filter out empty lines
    return "\n".join(non_empty_lines)  # Join the non-empty lines back together


file_path = 'results.log'
cdate = datetime.datetime.now()
fdate = cdate.strftime("==== %Y-%m-%d %H:%M:%S ====")
file = open(file_path, "a")
file.write(fdate + '\n')
file.close()


directory = './'
root_path = os.getcwd() + '/'

items = os.listdir(directory)
folders = [item for item in items if os.path.isdir(os.path.join(directory, item))]

folder_to_remove = '.git'
if folder_to_remove in folders:
    folders.remove(folder_to_remove)

folder_to_remove = 'dapt'
if folder_to_remove in folders:
    folders.remove(folder_to_remove)

folder_to_remove = 'mcm'
if folder_to_remove in folders:
    folders.remove(folder_to_remove)

folder_to_remove = '.vscode'
if folder_to_remove in folders:
    folders.remove(folder_to_remove)

choices=folders


questions = [inquirer.Checkbox(
    'bench',
    message="What are you interested in?",
    choices=sorted(folders),
)]
answers = inquirer.prompt(questions)  # returns a dict

benchmarks = answers['bench']


questions = [inquirer.Checkbox(
    'compilers',
    message="What are you interested in?",
    choices=['orig', 'pluto', 'traco', 'dapt'],
)]
answers = inquirer.prompt(questions)  # returns a dict
optimizers = answers['compilers']

size = input("Enter size: ")
threads = input("Enter threads: ")

print(benchmarks)
print(optimizers)

for bench in benchmarks:
    for optimizer in optimizers:
        # Run the program with parameters

        method = 1
        if(optimizer == "pluto"):
             method = 2
        if(optimizer == "traco"):
             method = 3
        if(optimizer == "dapt"):
             method = 5

        microbenches = []
        if(bench != "mea"):
            microbenches = [bench]
        else:
            microbenches = ['mcc', 'pb', 'pu', 'mea']

        for item in microbenches:
            process = subprocess.Popen([root_path + bench + '/' + item, threads, size, str(method)], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
            process.wait()
            output, error = process.communicate()
            output = output.decode()
            error = error.decode()
            
            itembench = ""
            if(bench != "mea"):
                itembench = bench
            else:
                itembench = item

            stuff = itembench + '\t', optimizer, '\tN ' + size, '\tThreads ' + threads + '  \t' + remove_empty_lines(output)

            print(itembench + '\t', optimizer, '\tN ' + size, '\tThreads ' + threads + '  \t' + remove_empty_lines(output))

            file = open(file_path, 'a')
            
            s = ' '.join(str(element) for element in stuff)

            file.write(s + '\n')
            file.close()

       


#0.0009
#
# Performance counter stats for 'system wide':
# 0.12 Joules power/energy-pkg/                                           
# 0.001645201 seconds time elapsed